
from __future__ import annotations

import difflib
import hashlib
import ipaddress
import io
import json
import logging
import os
import re
import socket
import threading
import time
import traceback
import zipfile
from concurrent.futures import ThreadPoolExecutor, as_completed
from dataclasses import dataclass, field
from datetime import datetime
from pathlib import Path
from typing import Any

import paramiko
from fastapi import FastAPI, File, Form, HTTPException, Request, UploadFile
from fastapi.responses import HTMLResponse, RedirectResponse, StreamingResponse
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill

APP_NAME = "Switch Health Dashboard"
APP_VERSION = "Alpha 3.2 Cisco Port Map"
APP_BANNER = f"{APP_NAME} — {APP_VERSION}"
DEFAULT_PORT = 22
MAX_PORT_MAC_SCAN_COMMANDS = 384
DEFAULT_SCAN_CONCURRENCY = 10
MAX_SCAN_CONCURRENCY = 25
MAX_DISCOVERY_HOSTS = 2048
MAX_IN_MEMORY_LOG_LINES = 1200
PARAMIKO_LOGGER = logging.getLogger("paramiko")
PARAMIKO_LOGGER.setLevel(logging.CRITICAL)
PARAMIKO_LOGGER.propagate = False

BASE_DIR = Path(__file__).resolve().parent
TEMPLATES = Jinja2Templates(directory=str(BASE_DIR / "templates"))
STATIC_DIR = BASE_DIR / "static"
APP_DATA = Path(os.environ.get("LOCALAPPDATA", str(Path.home()))) / "SwitchHealthDashboard"
LOG_DIR = APP_DATA / "Logs"
EXPORT_DIR = APP_DATA / "Exports"
HISTORY_DIR = APP_DATA / "History"
HISTORY_JOBS_DIR = HISTORY_DIR / "Jobs"
HISTORY_SWITCH_DIR = HISTORY_DIR / "BySwitch"
for _path in (LOG_DIR, EXPORT_DIR, HISTORY_DIR, HISTORY_JOBS_DIR, HISTORY_SWITCH_DIR):
    _path.mkdir(parents=True, exist_ok=True)

ANSI_RE = re.compile(r"\x1B(?:[@-Z\\-_]|\[[0-?]*[ -/]*[@-~])")
PORT_RE = re.compile(r"(?P<port>(?:[A-Za-z]{1,4}\d+(?:/\d+){0,2}|Po\d+|[A-Za-z]\d+|\d+/[A-Za-z]\d+|\d+/\d+/\d+|\d+/\d+|\d+))", re.I)
SPEED_RE = re.compile(r"(?P<speed>\d+)\s*(?:M|Mbps|Mb/s|G|Gbps)?", re.I)

app = FastAPI(title=APP_BANNER)
if STATIC_DIR.exists():
    app.mount("/static", StaticFiles(directory=str(STATIC_DIR)), name="static")

jobs: dict[str, "ScanJob"] = {}
jobs_lock = threading.Lock()
log_lock = threading.Lock()


@dataclass
class DiscoveryCandidate:
    ip: str
    hostname: str = ""
    discovered_by: str = ""
    suspected_vendor: str = "unknown"
    ssh_open: bool = False
    ssh_banner: str = ""
    confidence: str = "low"
    selected: bool = False


@dataclass
class Finding:
    severity: str
    category: str
    summary: str
    port: str = ""
    evidence: str = ""
    likely_cause: str = ""
    recommended_action: str = ""
    remediation: str = ""


@dataclass
class ScanResult:
    ip: str
    port: int
    vendor: str = "unknown"
    hostname: str = ""
    auth_note: str = ""
    sections: dict[str, dict[str, str]] = field(default_factory=dict)
    parsed: dict[str, Any] = field(default_factory=dict)
    findings: list[Finding] = field(default_factory=list)
    success: bool = False
    error: str = ""
    checked_at: str = ""


@dataclass
class ScanJob:
    job_id: str
    created_at: str
    status: str = "queued"
    log_lines: list[str] = field(default_factory=list)
    results: list[ScanResult] = field(default_factory=list)
    discovery_candidates: list[DiscoveryCandidate] = field(default_factory=list)
    listed_targets: list[tuple[str, int]] = field(default_factory=list)
    sections: list[str] = field(default_factory=list)
    entered_username: str = ""
    entered_password: str = ""
    vendor_choice: str = "auto"
    enable_discovery: bool = False
    discovery_subnet: str = ""
    current_targets: list[tuple[str, int]] = field(default_factory=list)
    enable_show_tech: bool = False
    enable_port_map: bool = False
    port_map_subnet: str = ""
    scan_concurrency: int = DEFAULT_SCAN_CONCURRENCY
    enable_debug: bool = False
    debug_log_path: str = ""
    baseline_profile: str = "none"
    custom_required_vlans: list[int] = field(default_factory=list)
    custom_require_aaa: bool = False
    custom_require_snmp: bool = False
    custom_require_dot1x: bool = False

    def log(self, message: str) -> None:
        stamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        line = f"[{stamp}] {message}"
        with log_lock:
            self.log_lines.append(line)
            if len(self.log_lines) > MAX_IN_MEMORY_LOG_LINES:
                self.log_lines[:] = self.log_lines[-MAX_IN_MEMORY_LOG_LINES:]
            with (LOG_DIR / f"switch_dashboard_{self.job_id}.log").open("a", encoding="utf-8", errors="ignore") as handle:
                handle.write(line + "\n")

    def debug_log(self, message: str) -> None:
        if not self.enable_debug:
            return
        stamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        safe = (message or "").replace(self.entered_password or "__NO_PASSWORD__", "<redacted>")
        line = f"[{stamp}] [DEBUG] {safe}"
        with log_lock:
            with (LOG_DIR / f"switch_dashboard_{self.job_id}_debug.log").open("a", encoding="utf-8", errors="ignore") as handle:
                handle.write(line + "\n")


VENDOR_ALIASES = {
    "auto": "Auto Detect",
    "ruckus": "Ruckus ICX",
    "aruba_cx": "Aruba CX",
    "hp_procurve": "HP / Aruba ProCurve",
    "tplink_media_panel": "TP-Link Media Panel",
    "cisco_ios": "Cisco IOS / Catalyst",
}


@dataclass(frozen=True)
class SectionProfile:
    label: str
    commands: tuple[str, ...]


VENDOR_PROFILES: dict[str, dict[str, SectionProfile]] = {
    "ruckus": {
        "system": SectionProfile("System / Version", ("show version", "show stack")),
        "ports": SectionProfile("Port Information", ("show interfaces brief wide", "show interfaces brief", "show statistics ethernet")),
        "stp": SectionProfile("Spanning Tree", ("show spanning-tree", "show spanning-tree detail")),
        "power": SectionProfile("PoE", ("show inline power", "show inline power detail", "show inline power emesg")),
        "vlan": SectionProfile("VLANs", ("show vlan",)),
        "lldp": SectionProfile("LLDP", ("show lldp neighbors", "show lldp neighbors detail")),
        "logs": SectionProfile("Logs", ("show logging", "show log")),
        "showtech": SectionProfile("Show Tech / Full Investigation", ("show tech-support",)),
    },
    "aruba_cx": {
        "system": SectionProfile("System / Version", ("show version", "show vsf")),
        "ports": SectionProfile("Port Information", ("show interface brief", "show interface")),
        "stp": SectionProfile("Spanning Tree", ("show spanning-tree detail", "show spanning-tree summary root")),
        "power": SectionProfile("PoE", ("show power-over-ethernet", "show power-over-ethernet brief")),
        "vlan": SectionProfile("VLANs", ("show vlan", "show vlan summary")),
        "lldp": SectionProfile("LLDP", ("show lldp neighbor-info", "show lldp neighbor-info detail", "show lldp local-device")),
        "logs": SectionProfile("Logs", ("show events",)),
        "showtech": SectionProfile("Show Tech / Full Investigation", ("show tech all", "show support")),
    },
    "hp_procurve": {
        "system": SectionProfile("System / Version", ("show system", "show version")),
        "ports": SectionProfile("Port Information", ("show interfaces brief", "show interfaces", "show name")),
        "stp": SectionProfile("Spanning Tree", ("show spanning-tree", "show spanning-tree config")),
        "power": SectionProfile("PoE", ("show power-management brief", "show power-management")),
        "vlan": SectionProfile("VLANs", ("show vlan", "show trunks")),
        "lldp": SectionProfile("LLDP", ("show lldp info remote-device", "show lldp info remote-device detail")),
        "logs": SectionProfile("Logs", ("show log", "show logging")),
        "showtech": SectionProfile("Show Tech / Full Investigation", ("show tech all",)),
    },
    "tplink_media_panel": {
        "system": SectionProfile("System / Version", ("show system-info", "show running-config")),
        "ports": SectionProfile("Port Information", ("show interface configuration", "show port all")),
        "stp": SectionProfile("Spanning Tree", ("show spanning-tree",)),
        "power": SectionProfile("PoE", ("show power",)),
        "vlan": SectionProfile("VLANs", ("show interface switchport", "show vlan")),
        "lldp": SectionProfile("LLDP", ("show lldp", "show lldp neighbor-information interface", "show lldp local-information interface")),
        "logs": SectionProfile("Logs", ("show logging",)),
        "showtech": SectionProfile("Show Tech / Full Investigation", ("show tech-support", "show support")),
    },
    "cisco_ios": {
        "system": SectionProfile("System / Version", ("show version",)),
        "ports": SectionProfile("Port Information", ("show interface status", "show interfaces status")),
        "stp": SectionProfile("Spanning Tree", ("show spanning-tree", "show spanning-tree summary")),
        "power": SectionProfile("PoE", ("show power inline", "show power inline police")),
        "vlan": SectionProfile("VLANs", ("show vlan brief", "show interfaces trunk")),
        "lldp": SectionProfile("LLDP", ("show lldp neighbors", "show lldp neighbors detail")),
        "logs": SectionProfile("Logs", ("show logging",)),
        "showtech": SectionProfile("Show Tech / Full Investigation", ("show tech-support",)),
    },
}

INFRA_KEYWORDS = ("sw", "switch", "idf", "mdf", "ap", "ruckus", "aruba", "tplink", "tp-link", "gateway", "firewall", "controller", "cisco", "catalyst")


BASELINE_PROFILES: dict[str, dict[str, Any]] = {
    "none": {"label": "No baseline", "required_vlans": set(), "require_aaa": False, "require_snmp": False, "require_dot1x": False},
    "marriott_bas": {"label": "Marriott BAS", "required_vlans": {100, 101, 130, 910, 1000, 1001, 1016}, "require_aaa": True, "require_snmp": True, "require_dot1x": True},
    "marriott_mic": {"label": "Marriott MIC", "required_vlans": {100, 101, 130, 450, 451, 900, 903, 910, 1000, 1001, 1016, 1017}, "require_aaa": True, "require_snmp": True, "require_dot1x": True},
    "marriott_ful": {"label": "Marriott FUL", "required_vlans": {100, 101, 130, 200, 201, 202, 203, 300, 301, 450, 451, 900, 903, 910, 1000, 1001, 1016, 1017}, "require_aaa": True, "require_snmp": True, "require_dot1x": True},
    "hyatt": {"label": "Hyatt", "required_vlans": {100, 101}, "require_aaa": True, "require_snmp": True, "require_dot1x": True},
    "custom": {"label": "Custom", "required_vlans": set(), "require_aaa": False, "require_snmp": False, "require_dot1x": False},
}


def normalize_port_token(value: str) -> str:
    return (value or "").strip().replace("Ten-GigabitEthernet", "te").replace("GigabitEthernet", "gi").replace("gigabitEthernet", "gi")


def sort_port_label(value: str) -> list[Any]:
    return [int(part) if part.isdigit() else part.lower() for part in re.split(r"(\d+)", str(value or ""))]


def lldp_neighbor_lines(text: str) -> list[dict[str, str]]:
    entries: list[dict[str, str]] = []
    current: dict[str, str] | None = None
    for raw in (text or '').splitlines():
        line = raw.strip()
        if not line:
            continue
        lower = line.lower()
        if any(k in lower for k in ["local port", "local interface", "port id", "port:"]) and PORT_RE.search(line):
            if current:
                entries.append(current)
            port_match = PORT_RE.search(line)
            current = {"local_port": port_match.group('port') if port_match else "", "detail": line}
            continue
        if current is None and PORT_RE.search(line) and any(k in lower for k in ["lldp", "remote", "neighbor"]):
            port_match = PORT_RE.search(line)
            current = {"local_port": port_match.group('port') if port_match else "", "detail": line}
        if current is None:
            continue
        current["detail"] = current.get("detail", "") + "\n" + line
        if any(k in lower for k in ["system name", "neighbor name", "system:"]):
            current["neighbor_name"] = line.split(":", 1)[-1].strip()
        elif any(k in lower for k in ["management address", "mgmt address"]):
            current["mgmt_ip"] = line.split(":", 1)[-1].strip()
        elif any(k in lower for k in ["port description", "neighbor port", "port desc", "port id"]) and ':' in line:
            current["neighbor_port"] = line.split(":", 1)[-1].strip()
    if current:
        entries.append(current)
    return [e for e in entries if e.get('local_port')]


def build_topology(job: ScanJob) -> dict[str, Any]:
    nodes: list[dict[str, Any]] = []
    edges_raw: list[dict[str, Any]] = []
    seen_nodes: set[str] = set()
    result_by_host = {((r.hostname or r.ip).lower()): r for r in job.results}
    result_by_ip = {r.ip: r for r in job.results}

    def add_node(node_id: str, label: str, node_type: str, vendor: str = "unknown", ip: str = "") -> None:
        if node_id in seen_nodes:
            return
        seen_nodes.add(node_id)
        nodes.append({"id": node_id, "label": label, "type": node_type, "vendor": vendor, "ip": ip})

    for result in sorted(job.results, key=lambda r: (r.hostname or r.ip, r.ip)):
        local_name = result.hostname or result.ip
        local_id = f"switch:{result.ip}"
        add_node(local_id, local_name, "switch", result.vendor, result.ip)
        interfaces = {item.get('port'): item for item in result.parsed.get('interfaces', [])}
        flap_ports = {f.port for f in result.findings if f.category == 'flapping' and f.port}
        # Use the vendor-specific LLDP parser so topology labels stay clean
        # and do not repeat local ports or chassis MACs from summary tables.
        entries = collect_lldp_entries(result)
        if not entries:
            for item in interfaces.values():
                if item.get('neighbor'):
                    entries.append({
                        'local_port': item.get('port', ''),
                        'neighbor_name': item.get('neighbor', ''),
                        'detail': item.get('line', '')
                    })
        for entry in entries:
            local_port = entry.get('local_port', '')
            iface = interfaces.get(local_port, {})
            neighbor_name = entry.get('neighbor_name') or iface.get('neighbor') or 'Unknown neighbor'
            neighbor_ip = entry.get('mgmt_ip', '')
            neighbor_port = entry.get('neighbor_port', '')
            neighbor_type = 'device'
            lname = neighbor_name.lower()
            if any(k in lname for k in ['ap', 'wap', 'air', 'omada']):
                neighbor_type = 'ap'
            elif any(k in lname for k in ['fw', 'firewall', 'gateway', 'router']):
                neighbor_type = 'gateway'
            elif any(k in lname for k in ['sw', 'switch', 'idf', 'mdf', 'stack']):
                neighbor_type = 'switch'
            node_key = f"neighbor:{neighbor_ip or neighbor_name}"
            scanned_neighbor = False
            remote_result = result_by_ip.get(neighbor_ip) if neighbor_ip else None
            if not remote_result and neighbor_name:
                remote_result = result_by_host.get(neighbor_name.lower())
            if remote_result:
                scanned_neighbor = True
                node_key = f"switch:{remote_result.ip}"
                neighbor_name = remote_result.hostname or remote_result.ip
                neighbor_ip = remote_result.ip
                neighbor_type = 'switch'
            add_node(node_key, neighbor_name, neighbor_type, remote_result.vendor if remote_result else 'unknown', neighbor_ip)
            speed = iface.get('speed_mbps')
            duplex = iface.get('duplex', '')
            issues: list[str] = []
            health = 'healthy'
            if iface.get('status') == 'up' and speed and speed < 1000 and (iface.get('role') == 'infrastructure' or neighbor_type in {'switch', 'ap', 'gateway'}):
                issues.append(f'{speed}M link')
                health = 'warning'
            if iface.get('duplex') == 'half':
                issues.append('half duplex')
                health = 'critical'
            if iface.get('errors', 0) > 100 or iface.get('crc', 0) > 0:
                issues.append('errors')
                health = 'critical' if iface.get('crc', 0) > 0 else max(health, 'warning')
            if local_port in flap_ports:
                issues.append('flapping')
                health = 'critical' if health == 'warning' else health
            mac_info = macs_for_port(result, local_port) if neighbor_type != 'switch' else {'macs': [], 'vlans': [], 'raw': ''}
            vlan_value = iface.get('vlan', '') or (', '.join(mac_info.get('vlans', [])) if mac_info.get('vlans') else '')
            edges_raw.append({
                'left_id': local_id,
                'left_name': local_name,
                'left_ip': result.ip,
                'left_port': local_port,
                'right_id': node_key,
                'right_name': neighbor_name,
                'right_ip': neighbor_ip,
                'right_port': neighbor_port,
                'right_type': neighbor_type,
                'untagged_vlan': vlan_value,
                'mac_addresses': mac_info.get('macs', []),
                'mac_count': len(mac_info.get('macs', [])),
                'scanned_neighbor': scanned_neighbor,
                'speed_mbps': speed or 0,
                'duplex': duplex or '',
                'health': health,
                'issues': issues,
                'detail': entry.get('detail', ''),
            })

    deduped: list[dict[str, Any]] = []
    seen_edges: set[tuple[str, str, str, str]] = set()
    for edge in sorted(edges_raw, key=lambda e: (e['left_name'], sort_port_label(e['left_port']), e['right_name'])):
        if edge['scanned_neighbor'] and edge['right_id'].startswith('switch:'):
            key = tuple(sorted([edge['left_id'], edge['right_id']])) + tuple(sorted([normalize_port_token(edge['left_port']), normalize_port_token(edge['right_port'])]))
        else:
            key = (edge['left_id'], edge['right_id'], normalize_port_token(edge['left_port']), normalize_port_token(edge['right_port']))
        if key in seen_edges:
            continue
        seen_edges.add(key)
        deduped.append(edge)

    summary = {
        'nodes': len(nodes),
        'edges': len(deduped),
        'warning_links': sum(1 for e in deduped if e['health'] == 'warning'),
        'critical_links': sum(1 for e in deduped if e['health'] == 'critical'),
        'unconfirmed_links': sum(1 for e in deduped if not e['scanned_neighbor']),
    }
    by_switch: list[dict[str, Any]] = []
    for node in sorted([n for n in nodes if n['type'] == 'switch'], key=lambda n: n['label'].lower()):
        switch_edges = [e for e in deduped if e['left_id'] == node['id']]
        by_switch.append({'node': node, 'edges': switch_edges})
    return {'nodes': nodes, 'edges': deduped, 'summary': summary, 'by_switch': by_switch}


def clean_output(text: str) -> str:
    text = ANSI_RE.sub("", text or "")
    text = text.replace("\r", "")
    cleaned = []
    for raw in text.splitlines():
        line = re.sub(r"Press any key to continue.*", "", raw, flags=re.I)
        line = re.sub(r"--\s*more\s*--.*", "", line, flags=re.I).strip("\n")
        if line:
            cleaned.append(line.rstrip())
    return "\n".join(cleaned).strip()



def configure_debug_logging(job: ScanJob) -> None:
    if not job.enable_debug:
        PARAMIKO_LOGGER.setLevel(logging.CRITICAL)
        return
    job.debug_log_path = str(LOG_DIR / f"switch_dashboard_{job.job_id}_debug.log")
    job.debug_log(f"Debug logging enabled. Debug log path: {job.debug_log_path}")
    job.debug_log(f"Targets: {job.listed_targets}")
    job.debug_log(f"Vendor choice: {job.vendor_choice}; Sections: {job.sections}; Concurrency: {job.scan_concurrency}")
    PARAMIKO_LOGGER.setLevel(logging.DEBUG)
    # Avoid adding duplicate handlers for the same job when a page is reloaded or validation is reapplied.
    target_path = str(LOG_DIR / f"switch_dashboard_{job.job_id}_paramiko.log")
    for handler in PARAMIKO_LOGGER.handlers:
        if getattr(handler, "baseFilename", None) == target_path:
            return
    handler = logging.FileHandler(target_path, encoding="utf-8")
    handler.setLevel(logging.DEBUG)
    handler.setFormatter(logging.Formatter("%(asctime)s [%(levelname)s] %(name)s: %(message)s"))
    PARAMIKO_LOGGER.addHandler(handler)

def command_rejected(output: str) -> bool:
    lower = (output or "").lower()
    patterns = [
        "invalid input",
        "unknown command",
        "invalid parameter",
        "ambiguous command",
        "not recognized",
        "incomplete command",
    ]
    return any(p in lower for p in patterns)


def detect_vendor(text: str) -> str:
    lower = (text or "").lower()
    if "arubaos-switch" in lower or "procurve" in lower or re.search(r"software revision\s+:\s+[a-z]\.\d+", lower):
        return "hp_procurve"
    if "arubaos-cx" in lower or "service os version" in lower or "build sha" in lower:
        return "aruba_cx"
    if "jetstream" in lower or "tp-link" in lower or "tl-sg" in lower or "system-info" in lower:
        return "tplink_media_panel"
    if "cisco ios software" in lower or "cisco ios xe software" in lower or "catalyst" in lower or "c2960" in lower or "c9300" in lower or "c9200" in lower:
        return "cisco_ios"
    if "ruckus" in lower or "fastiron" in lower or "stack unit" in lower:
        return "ruckus"
    return "unknown"


def parse_targets(raw: str) -> list[tuple[str, int]]:
    targets: list[tuple[str, int]] = []
    seen: set[tuple[str, int]] = set()
    for line in raw.splitlines():
        line = line.strip()
        if not line:
            continue
        port = 22
        host = line
        if "," in line:
            host, port_s = [x.strip() for x in line.split(",", 1)]
            port = int(port_s)
        elif ":" in line and line.count(":") == 1 and re.match(r"^\d+\.\d+\.\d+\.\d+:\d+$", line):
            host, port_s = line.split(":", 1)
            port = int(port_s)
        socket.inet_aton(host)
        target = (host, port)
        if target not in seen:
            seen.add(target)
            targets.append(target)
    return targets




def expand_subnet_targets(raw_subnet: str, default_port: int = 22, max_hosts: int = MAX_DISCOVERY_HOSTS) -> list[tuple[str, int]]:
    """Expand a CIDR subnet into SSH targets for subnet-only port mapping.

    This is intentionally bounded so a mistyped /16 does not create thousands of
    slow SSH attempts from a field laptop.
    """
    raw_subnet = (raw_subnet or "").strip()
    if not raw_subnet:
        return []
    network = ipaddress.ip_network(raw_subnet, strict=False)
    targets: list[tuple[str, int]] = []
    for idx, ip in enumerate(network.hosts()):
        if idx >= max_hosts:
            break
        targets.append((str(ip), default_port))
    return targets

def ensure_list(value: list[str] | None, enable_show_tech: bool = False) -> list[str]:
    sections = value or ["system", "ports", "stp", "power", "vlan", "lldp", "logs"]
    if enable_show_tech and "showtech" not in sections:
        sections.append("showtech")
    return sections


class SSHShell:
    def __init__(self, host: str, port: int, timeout: int = 10):
        self.host = host
        self.port = port
        self.timeout = timeout
        self.client: paramiko.SSHClient | None = None
        self.channel = None
        self.auth_note = ""

    def connect(self, vendor_hint: str, username: str, password: str, job: ScanJob) -> tuple[str, str]:
        attempts = [(username, password)]
        if vendor_hint == "tplink_media_panel":
            attempts.extend([("admin", "admin"), ("admin", "51nGleD")])

        last_error: Exception | None = None
        for attempt_user, attempt_pass in attempts:
            try:
                job.debug_log(f"[{self.host}:{self.port}] SSH login attempt as {attempt_user!r} with vendor hint {vendor_hint!r}")
                client = paramiko.SSHClient()
                client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
                client.connect(
                    hostname=self.host,
                    port=self.port,
                    username=attempt_user,
                    password=attempt_pass,
                    timeout=self.timeout,
                    auth_timeout=self.timeout,
                    banner_timeout=self.timeout,
                    look_for_keys=False,
                    allow_agent=False,
                )
                self.client = client
                self.channel = client.invoke_shell(width=240, height=4000)
                self.channel.settimeout(self.timeout)
                time.sleep(0.9)
                self._drain()
                self._disable_paging()
                if vendor_hint == "tplink_media_panel" and attempt_user == "admin" and attempt_pass == "51nGleD":
                    self.auth_note = "Authentication Note: Logged in using TP-Link fallback credentials. Non-standard password detected."
                elif vendor_hint == "tplink_media_panel" and (attempt_user, attempt_pass) != (username, password):
                    self.auth_note = "Authentication Note: Logged in using TP-Link fallback credentials."
                job.debug_log(f"[{self.host}:{self.port}] SSH login succeeded as {attempt_user!r}")
                return attempt_user, attempt_pass
            except Exception as exc:
                last_error = exc
                job.debug_log(f"[{self.host}:{self.port}] SSH login attempt failed as {attempt_user!r}: {type(exc).__name__}: {exc}\n{traceback.format_exc()}")
                continue
        if last_error and "Error reading SSH protocol banner" in str(last_error):
            raise RuntimeError("SSH banner was not received. The host may not be SSH, may have closed the connection, or may be slow/overloaded.")
        raise RuntimeError("Authentication failed")

    def _disable_paging(self) -> None:
        for cmd in ("skip", "no page", "terminal length 0"):
            try:
                self.channel.send(cmd + "\n")
                time.sleep(0.25)
                self._drain()
            except Exception:
                pass

    def _drain(self) -> str:
        output = ""
        if not self.channel:
            return output
        while self.channel.recv_ready():
            output += self.channel.recv(65535).decode(errors="ignore")
        return output

    def run(self, command: str, allow_more: bool = True, initial_wait: float = 1.0, quiet_limit: int = 6, job: ScanJob | None = None) -> str:
        if not self.channel:
            raise RuntimeError("SSH not connected")
        if job:
            job.debug_log(f"[{self.host}:{self.port}] RUN: {command}")
        try:
            self.channel.send(command + "\n")
            time.sleep(initial_wait)
            output = ""
            quiet = 0
            while quiet < quiet_limit:
                if self.channel.recv_ready():
                    chunk = self.channel.recv(65535).decode(errors="ignore")
                    output += chunk
                    quiet = 0
                    lower = chunk.lower()
                    if allow_more and ("press any key to continue" in lower or "--more--" in lower or "-- more --" in lower):
                        self.channel.send(" ")
                        time.sleep(0.2)
                else:
                    quiet += 1
                    time.sleep(0.35)
            cleaned = clean_output(output)
            if job:
                preview = cleaned if len(cleaned) <= 12000 else cleaned[:12000] + "\n... <debug output truncated in preview; raw command output exceeded 12000 chars>"
                job.debug_log(f"[{self.host}:{self.port}] OUTPUT for {command}:\n{preview}")
            return cleaned
        except Exception as exc:
            if job:
                job.debug_log(f"[{self.host}:{self.port}] ERROR while running {command}: {type(exc).__name__}: {exc}\n{traceback.format_exc()}")
            raise

    def maybe_enable(self, vendor: str, entered_password: str) -> None:
        if vendor != "tplink_media_panel" or not self.channel:
            return
        try:
            self.channel.send("enable\n")
            time.sleep(0.5)
            out = self._drain().lower()
            if "password" in out:
                for pw in (entered_password, "admin", "51nGleD"):
                    self.channel.send(pw + "\n")
                    time.sleep(0.5)
                    check = self._drain().lower()
                    if "invalid" not in check and "error" not in check:
                        break
        except Exception:
            pass

    def close(self) -> None:
        try:
            if self.client:
                self.client.close()
        except Exception:
            pass


def parse_hostname(result: ScanResult) -> str:
    # Avoid scanning huge show-tech blobs just to find a hostname.
    # System/detection output is normally enough and keeps large investigations responsive.
    chunks: list[str] = []
    for section_name in ("system", "lldp"):
        for output in result.sections.get(section_name, {}).values():
            if output:
                chunks.append(output[:200_000])
    if not chunks:
        for section in result.sections.values():
            for output in section.values():
                if output:
                    chunks.append(output[:50_000])
                    break
            if chunks:
                break
    text = "\n".join(chunks)
    patterns = [
        r'hostname\s+"?([A-Za-z0-9._:-]+)"?',
        r"System Name\s*:\s*([A-Za-z0-9._:-]+)",
        r"Prompt.*?([A-Za-z0-9._:-]+)#",
    ]
    for pat in patterns:
        match = re.search(pat, text, flags=re.I)
        if match:
            return match.group(1).strip()
    return result.ip


def parse_interfaces(result: ScanResult) -> list[dict[str, Any]]:
    text = "\n".join(result.sections.get("ports", {}).values()) + "\n" + "\n".join(result.sections.get("lldp", {}).values())
    if result.vendor == "cisco_ios":
        cisco_interfaces = parse_cisco_interface_status_rows(text)
        if cisco_interfaces:
            return sorted(cisco_interfaces.values(), key=lambda x: sort_port_label(x.get("port", "")))
    interfaces: dict[str, dict[str, Any]] = {}
    for line in text.splitlines():
        port_match = PORT_RE.search(line)
        if not port_match:
            continue
        port = port_match.group("port")
        entry = interfaces.setdefault(port, {"port": port, "line": line.strip(), "speed_mbps": None, "duplex": "", "neighbor": "", "role": "unknown", "errors": 0, "crc": 0, "status": ""})
        lower = line.lower()
        if "up" in lower:
            entry["status"] = "up"
        if "down" in lower and not entry["status"]:
            entry["status"] = "down"
        speed = None
        if "1000" in lower or "1g" in lower or "1 g" in lower:
            speed = 1000
        elif "100m" in lower or "100 " in lower:
            speed = 100
        elif "10m" in lower or "10 " in lower:
            speed = 10
        if speed:
            entry["speed_mbps"] = speed
        if "half" in lower:
            entry["duplex"] = "half"
        elif "full" in lower:
            entry["duplex"] = "full"
        if any(k in lower for k in INFRA_KEYWORDS):
            entry["role"] = "infrastructure"
            entry["neighbor"] = line.strip()
        err_match = re.search(r"(crc|input errors|output errors|errors)\D+(\d+)", lower)
        if err_match:
            value = int(err_match.group(2))
            if "crc" in err_match.group(1):
                entry["crc"] = max(entry["crc"], value)
            entry["errors"] = max(entry["errors"], value)
    return sorted(interfaces.values(), key=lambda x: [int(p) if p.isdigit() else p for p in re.split(r"(\d+)", x["port"])])


def normalize_log_message(line: str) -> tuple[str, str, str]:
    """Return (category, port, summary) for log aggregation."""
    original = (line or "").strip()
    cleaned = original
    cleaned = re.sub(r"^\w{3}\s+\d{1,2}\s+\d{1,2}:\d{2}:\d{2}\s*:?\s*", "", cleaned)
    cleaned = re.sub(r"^\d{4}-\d{2}-\d{2}\s+\d{1,2}:\d{2}:\d{2}\s*", "", cleaned)
    cleaned = re.sub(r"^(?:[A-Za-z0-9_.-]+:)?\s*System:\s*", "", cleaned, flags=re.I)
    cleaned = re.sub(r"^(?:Warning|Error|Info|Notice|Critical):\s*", "", cleaned, flags=re.I)

    lower = cleaned.lower()
    category = "logs"
    if any(x in lower for x in ["poe", "power disabled", "power denied", "overload", "pd overload"]):
        category = "poe"
    elif any(x in lower for x in ["topology change", "root change", "bpdu", "loop"]):
        category = "stp"

    cleaned = re.sub(r"^(?:PoE|Power|STP|MSTP|System):\s*", "", cleaned, flags=re.I).strip()
    match = re.search(r"(Power disabled on port\s+([A-Za-z0-9_./-]+)\s+because of\s+[^.]+\.)", cleaned, flags=re.I)
    if match:
        return "poe", match.group(2), match.group(1).strip()

    port_match = PORT_RE.search(cleaned)
    port = port_match.group("port") if port_match else ""
    summary = cleaned.strip() or original
    return category, port, summary


def parse_log_findings(result: ScanResult) -> list[Finding]:
    findings: list[Finding] = []
    text = "\n".join(result.sections.get("logs", {}).values())
    ignored = ["login failed", "authentication failed", "bad password", "invalid user"]
    flap_counters: dict[str, int] = {}
    grouped_events: dict[tuple[str, str, str, str], dict[str, Any]] = {}

    def add_grouped_event(severity: str, category: str, summary: str, port: str, raw_line: str) -> None:
        normalized = re.sub(r"\s+", " ", summary.strip()).lower()
        key = (severity, category, port or "", normalized)
        item = grouped_events.setdefault(key, {
            "severity": severity,
            "category": category,
            "summary": summary.strip(),
            "port": port or "",
            "count": 0,
            "sample": raw_line.strip(),
        })
        item["count"] += 1

    for line in text.splitlines():
        raw_line = line.strip()
        lower = raw_line.lower()
        if not raw_line or any(x in lower for x in ignored):
            continue

        if any(x in lower for x in ["link down", "link up", "changed state", "port down", "port up"]):
            port = PORT_RE.search(raw_line)
            key = port.group("port") if port else "unknown"
            flap_counters[key] = flap_counters.get(key, 0) + 1
            continue

        if any(x in lower for x in ["topology change", "root change", "bpdu", "loop"]):
            category, port, summary = normalize_log_message(raw_line)
            severity = "warning" if "topology" in lower else "critical"
            add_grouped_event(severity, category or "stp", summary, port, raw_line)
            continue

        if any(x in lower for x in ["crc", "transceiver", "media error", "power denied", "overload", "poe fault", "power disabled"]):
            category, port, summary = normalize_log_message(raw_line)
            add_grouped_event("warning", category, summary, port, raw_line)

    for item in grouped_events.values():
        count = int(item.get("count") or 0)
        summary = item["summary"]
        if count > 1:
            summary = f"{summary} Seen {count} times."
        evidence = f"{count} matching log event{'s' if count != 1 else ''}. Sample: {item['sample']}"
        findings.append(Finding(item["severity"], item["category"], summary, port=item.get("port", ""), evidence=evidence))

    for port, count in flap_counters.items():
        if count >= 2:
            findings.append(Finding("warning", "flapping", f"Port {port} appears to be flapping ({count} link-state log events).", port=port, evidence=f"{count} log events"))
    return findings


def parse_vlan_ids(result: ScanResult) -> set[int]:
    vlan_ids: set[int] = set()
    vlan_text = "\n".join(result.sections.get("vlan", {}).values())
    for line in vlan_text.splitlines():
        for match in re.finditer(r"(?:^|\b)(\d{1,4})(?:\b)", line):
            value = int(match.group(1))
            if 1 <= value <= 4094:
                vlan_ids.add(value)
    return vlan_ids


def get_baseline_requirements(job: ScanJob) -> dict[str, Any]:
    profile = dict(BASELINE_PROFILES.get(job.baseline_profile or "none", BASELINE_PROFILES["none"]))
    if (job.baseline_profile or "none") == "custom":
        profile["required_vlans"] = set(job.custom_required_vlans)
        profile["require_aaa"] = job.custom_require_aaa
        profile["require_snmp"] = job.custom_require_snmp
        profile["require_dot1x"] = job.custom_require_dot1x
    return profile


def infer_finding_guidance(finding: Finding, result: ScanResult) -> Finding:
    category = (finding.category or "").lower()
    summary_lower = (finding.summary or "").lower()
    evidence_lower = (finding.evidence or "").lower()
    if category in {"speed", "crc", "errors"}:
        if "below 1000" in summary_lower and ("crc" in evidence_lower or category == "crc"):
            finding.likely_cause = "Likely bad cable or poor negotiation on an infrastructure-facing link."
            finding.recommended_action = "Inspect or replace the patch lead, verify both ends negotiate at 1000/full, and run cable diagnostics."
            finding.remediation = f"Check both ends of port {finding.port or 'the affected port'} and reset speed/duplex to auto."
        elif "below 1000" in summary_lower:
            finding.likely_cause = "Infrastructure link is negotiating below the expected speed."
            finding.recommended_action = "Check cabling, SFP/media type, and remote port settings."
            finding.remediation = f"Verify port {finding.port or 'the affected port'} is set to auto speed/duplex and confirm the remote device supports gigabit."
        elif category == "crc":
            finding.likely_cause = "Layer 1 errors are present on the link."
            finding.recommended_action = "Replace or reseat cabling and inspect the far-end interface for matching errors."
            finding.remediation = f"Run cable diagnostics on {finding.port or 'the affected port'} and replace the patch or horizontal cable if errors persist."
        else:
            finding.likely_cause = "Interface errors are accumulating beyond normal levels."
            finding.recommended_action = "Investigate physical media, duplex, and remote-port stability."
            finding.remediation = f"Review interface counters on {finding.port or 'the affected port'} and clear counters after remediation to confirm the fix."
    elif category == "flapping":
        finding.likely_cause = "The link is bouncing repeatedly, often due to a bad cable, unstable upstream device, or loop."
        finding.recommended_action = "Inspect the physical connection and correlate the port with STP and neighbor changes."
        finding.remediation = f"Trace port {finding.port or 'the affected port'}, replace the patch lead, and confirm the connected device is stable."
    elif category == "stp":
        finding.likely_cause = "Topology or loop-related events were seen in switch logs."
        finding.recommended_action = "Review neighboring links, unmanaged-switch indicators, and recent physical changes."
        finding.remediation = "Validate the intended root bridge, check for accidental loops, and confirm BPDU protections are configured where appropriate."
    elif category == "poe":
        finding.likely_cause = "The connected powered device is not receiving the expected power budget."
        finding.recommended_action = "Verify power class, budget availability, and whether the connected AP or device is drawing expected wattage."
        finding.remediation = f"Review PoE settings and budget on {finding.port or 'the affected port'} and re-negotiate power if supported."
    elif category == "mac":
        finding.likely_cause = "A likely unmanaged switch or mini-switch is connected."
        finding.recommended_action = "Trace the port and identify the downstream device before making changes."
        finding.remediation = f"Physically inspect what is connected to {finding.port or 'the affected port'} and replace or document any unmanaged switch."
    elif category == "compliance":
        finding.likely_cause = finding.likely_cause or "The current switch state does not meet the selected baseline."
        finding.recommended_action = finding.recommended_action or "Compare the switch against the required standard and correct missing controls."
        finding.remediation = finding.remediation or "Generate remediation commands and apply them during an approved change window."
    elif category == "duplex":
        finding.likely_cause = "Duplex mismatch or half-duplex operation on an infrastructure-facing link."
        finding.recommended_action = "Confirm both ends use auto negotiation or matching manual settings."
        finding.remediation = f"Reset speed/duplex to auto on {finding.port or 'the affected port'} and verify the remote end matches."
    else:
        finding.likely_cause = finding.likely_cause or "Additional review is needed to confirm the exact cause."
        finding.recommended_action = finding.recommended_action or "Review the raw evidence and related interface state."
        finding.remediation = finding.remediation or "Use the switch findings, topology, and history views to confirm the next action."
    return finding


def apply_baseline_validation(job: ScanJob, result: ScanResult, interfaces: list[dict[str, Any]]) -> list[Finding]:
    profile = get_baseline_requirements(job)
    findings: list[Finding] = []
    if (job.baseline_profile or "none") == "none":
        result.parsed["baseline"] = {"profile": "none", "required_vlans": []}
        return findings
    required_vlans = set(profile.get("required_vlans") or set())
    present_vlans = parse_vlan_ids(result)
    missing_vlans = sorted(required_vlans - present_vlans)
    if missing_vlans:
        findings.append(Finding(
            "critical",
            "compliance",
            f"Selected baseline is missing required VLANs: {', '.join(str(v) for v in missing_vlans)}.",
            evidence=f"Present VLANs: {', '.join(str(v) for v in sorted(present_vlans)) or 'none detected'}",
            likely_cause="Required VLANs from the selected baseline were not found in collected switch output.",
            recommended_action="Validate VLAN creation and uplink tagging against the baseline.",
            remediation="Create the missing VLANs and ensure they are permitted on required uplink or AP-facing ports.",
        ))
    config_chunks: list[str] = []
    for section_name in ("system", "vlan", "ports", "showtech"):
        for output in result.sections.get(section_name, {}).values():
            if output:
                config_chunks.append(output[:500_000])
    config_text = "\n".join(config_chunks).lower()
    if profile.get("require_snmp") and not any(token in config_text for token in ["snmp-server", "snmp", "community"]):
        findings.append(Finding(
            "warning",
            "compliance",
            "SNMP settings expected by the selected baseline were not detected.",
            evidence="No obvious SNMP configuration markers were found in collected output.",
            likely_cause="The switch may be missing the expected SNMP configuration or it was not exposed by collected commands.",
            recommended_action="Verify SNMP communities, access controls, and any required trap or read-only settings.",
            remediation="Add the required SNMP configuration for the site standard and confirm read-only access where expected.",
        ))
    if profile.get("require_aaa") and not any(token in config_text for token in ["aaa", "tacacs", "radius"]):
        findings.append(Finding(
            "critical",
            "compliance",
            "AAA controls expected by the selected baseline were not detected.",
            evidence="No obvious AAA, TACACS, or RADIUS configuration markers were found.",
            likely_cause="The switch may not be using the required centralized authentication method.",
            recommended_action="Confirm AAA, TACACS, or RADIUS settings against the selected standard.",
            remediation="Configure the required AAA method and test management authentication with the approved source."
        ))
    if profile.get("require_dot1x"):
        user_ports = [i for i in interfaces if i.get("status") == "up" and i.get("role") != "infrastructure"]
        if user_ports and not any(token in config_text for token in ["dot1x", "802.1x", "aaa port-access", "port-control auto"]):
            findings.append(Finding(
                "critical",
                "compliance",
                "802.1X was not detected for user-facing ports under the selected baseline.",
                evidence=f"User-facing active ports detected: {', '.join(i['port'] for i in user_ports[:12])}",
                likely_cause="The switch appears to have active user-facing ports without the expected access-control configuration.",
                recommended_action="Review edge-port authentication requirements for this property standard.",
                remediation="Enable the appropriate 802.1X or equivalent edge-port authentication profile on user-facing ports."
            ))
    result.parsed["baseline"] = {"profile": job.baseline_profile, "required_vlans": sorted(required_vlans), "present_vlans": sorted(present_vlans)}
    return findings


def build_remediation_plan(job: ScanJob) -> dict[str, list[dict[str, Any]]]:
    plans: dict[str, list[dict[str, Any]]] = {}
    for result in job.results:
        host = result.hostname or result.ip
        vendor = result.vendor
        commands: list[dict[str, Any]] = []
        for finding in result.findings:
            cmd_list: list[str] = []
            port = finding.port
            if finding.category in {"speed", "duplex"} and port:
                if vendor in {"hp_procurve", "aruba_cx"}:
                    cmd_list = [f"interface {port}", "speed auto", "duplex auto"]
                elif vendor == "ruckus":
                    cmd_list = [f"interface ethernet {port}", "speed-duplex auto"]
                elif vendor == "tplink_media_panel":
                    cmd_list = [f"interface gigabitEthernet {port}", "speed auto", "duplex auto"]
            elif finding.category == "compliance":
                required = result.parsed.get("baseline", {}).get("required_vlans", [])
                present = set(result.parsed.get("baseline", {}).get("present_vlans", []))
                real_missing = [v for v in required if v not in present]
                if real_missing:
                    for vlan in real_missing:
                        if vendor == "ruckus":
                            cmd_list.extend([f"vlan {vlan} name VLAN_{vlan}"])
                        elif vendor in {"hp_procurve", "aruba_cx"}:
                            cmd_list.extend([f"vlan {vlan}", f"name VLAN_{vlan}"])
                        elif vendor == "tplink_media_panel":
                            cmd_list.extend([f"vlan {vlan}"])
                if not cmd_list:
                    cmd_list = [f"! {finding.remediation or 'Review and correct the switch against the selected baseline.'}"]
            elif finding.category == "poe" and port:
                if vendor == "ruckus":
                    cmd_list = [f"interface ethernet {port}", "inline power"]
                elif vendor == "tplink_media_panel":
                    cmd_list = [f"interface gigabitEthernet {port}", "power inline auto"]
            if not cmd_list and finding.remediation:
                cmd_list = [f"! {finding.remediation}"]
            commands.append({"finding": finding, "commands": cmd_list})
        plans[host] = commands
    return plans


def apply_health_rules(job: ScanJob, result: ScanResult) -> None:
    interfaces = parse_interfaces(result)
    result.parsed["interfaces"] = interfaces
    findings = parse_log_findings(result)
    for item in interfaces:
        port = item["port"]
        if item["crc"] > 0:
            findings.append(Finding("warning", "crc", f"Port {port} has CRC errors.", port=port, evidence=item["line"]))
        if item["errors"] > 100:
            findings.append(Finding("warning", "errors", f"Port {port} has more than 100 errors and is a cable-diagnostics candidate.", port=port, evidence=item["line"]))
        if item["status"] == "up" and item["role"] == "infrastructure" and item.get("speed_mbps") and item["speed_mbps"] < 1000:
            sev = "critical" if "uplink" in item["line"].lower() or item.get("duplex") == "half" else "warning"
            findings.append(Finding(sev, "speed", f"Port {port} is linked to another device below 1000 Mbps.", port=port, evidence=item["line"]))
        if item["duplex"] == "half" and item["role"] == "infrastructure":
            findings.append(Finding("critical", "duplex", f"Port {port} is half duplex on an infrastructure-facing link.", port=port, evidence=item["line"]))
    findings.extend(apply_baseline_validation(job, result, interfaces))
    result.findings = [infer_finding_guidance(f, result) for f in findings]


def maybe_run_cable_test(shell: SSHShell, result: ScanResult, enabled: bool, job: ScanJob) -> None:
    if not enabled:
        return
    interfaces = result.parsed.get("interfaces") or parse_interfaces(result)
    cable_outputs: dict[str, str] = {}
    for item in interfaces:
        if item["errors"] <= 100:
            continue
        port = item["port"]
        try:
            if result.vendor == "ruckus":
                shell.run(f"phy cable-diagnostics tdr {port}", job=job)
                time.sleep(2.0)
                cable_outputs[port] = shell.run(f"show cable-diagnostics tdr {port}", job=job)
            elif result.vendor == "tplink_media_panel":
                cable_outputs[port] = shell.run(f"show cable-diagnostics interface gigabitEthernet {port}", job=job)
            if port in cable_outputs:
                job.log(f"[{result.ip}] Cable diagnostics collected on {port}")
        except Exception as exc:
            job.log(f"[{result.ip}] Cable diagnostics failed on {port}: {exc}")
    if cable_outputs:
        result.sections.setdefault("cable", {}).update(cable_outputs)


def scan_target(job: ScanJob, host: str, port: int, vendor_choice: str, username: str, password: str, sections: list[str], enable_cable_test: bool = True) -> ScanResult:
    result = ScanResult(ip=host, port=port, checked_at=datetime.now().strftime("%Y-%m-%d %H:%M:%S"))
    shell = SSHShell(host, port)
    try:
        shell.connect(vendor_choice if vendor_choice != "auto" else "auto", username, password, job)
        result.auth_note = shell.auth_note
        detect_cmds = {
            "auto": ("show version", "show system", "show system-info", "show running-config"),
            "hp_procurve": ("show system", "show version"),
            "aruba_cx": ("show version",),
            "tplink_media_panel": ("show system-info", "show running-config"),
            "ruckus": ("show version",),
            "cisco_ios": ("show version",),
        }.get(vendor_choice, ("show version",))
        detect_output = ""
        detected = vendor_choice if vendor_choice != "auto" else "unknown"
        for cmd in detect_cmds:
            out = shell.run(cmd, job=job)
            if out and not command_rejected(out):
                detect_output = out
                if vendor_choice == "auto":
                    detected = detect_vendor(out)
                    if detected != "unknown":
                        break
        result.vendor = detected if detected != "unknown" else ("hp_procurve" if "software revision" in detect_output.lower() else vendor_choice)
        if result.vendor == "unknown":
            result.vendor = detect_vendor(detect_output)
        if result.vendor == "unknown":
            raise RuntimeError("Could not detect vendor from device output")
        shell.maybe_enable(result.vendor, password)

        profile = VENDOR_PROFILES.get(result.vendor, {})
        wanted_sections = [s for s in sections if s in profile]
        result.sections.setdefault("system", {})
        if detect_output:
            result.sections["system"]["detection"] = detect_output
        for section in wanted_sections:
            for cmd in profile[section].commands:
                if section == "showtech":
                    out = shell.run(cmd, initial_wait=2.0, quiet_limit=20, job=job)
                else:
                    out = shell.run(cmd, job=job)
                if out and not command_rejected(out):
                    result.sections.setdefault(section, {})[cmd] = out
                    job.log(f"[{host}] Ran: {cmd}")
                else:
                    job.log(f"[{host}] Skipped/unsupported: {cmd}")
        result.hostname = parse_hostname(result)
        result.success = True
        apply_health_rules(job, result)
        collect_port_map_mac_addresses(shell, result, job)
        maybe_run_cable_test(shell, result, enable_cable_test, job)
    except Exception as exc:
        result.error = str(exc)
        if job.enable_debug:
            job.debug_log(f"[{host}:{port}] scan_target exception: {type(exc).__name__}: {exc}\n{traceback.format_exc()}")
        job.log(f"[{host}] Error: {exc}")
    finally:
        shell.close()
    return result


def discover_candidates(job: ScanJob) -> list[DiscoveryCandidate]:
    candidates: dict[str, DiscoveryCandidate] = {}
    listed_ips = {host for host, _ in job.listed_targets}
    if not job.enable_discovery:
        return []
    subnets: set[str] = set()
    if job.discovery_subnet:
        subnets.add(job.discovery_subnet.strip())
    else:
        for host, _ in job.listed_targets:
            try:
                net = ipaddress.ip_network(f"{host}/24", strict=False)
                subnets.add(str(net))
            except Exception:
                continue

    def probe(ip: str) -> DiscoveryCandidate | None:
        if ip in listed_ips:
            return None
        cand = DiscoveryCandidate(ip=ip, discovered_by="subnet sweep")
        try:
            rev = socket.gethostbyaddr(ip)[0]
            cand.hostname = rev
            cand.confidence = "medium"
        except Exception:
            pass
        try:
            with socket.create_connection((ip, 22), timeout=0.35) as sock:
                cand.ssh_open = True
                sock.settimeout(0.45)
                try:
                    banner = sock.recv(128).decode(errors="ignore").strip()
                except Exception:
                    banner = ""
            cand.ssh_banner = banner
            lower = banner.lower()
            if "tp-link" in lower or "jetstream" in lower:
                cand.suspected_vendor = "tplink_media_panel"
                cand.confidence = "high"
            elif "aruba" in lower or "procurve" in lower:
                cand.suspected_vendor = "hp_procurve"
                cand.confidence = "high"
            elif "ruckus" in lower or "brocade" in lower:
                cand.suspected_vendor = "ruckus"
                cand.confidence = "high"
            elif banner:
                cand.confidence = "medium"
        except Exception:
            return None
        return cand if cand.ssh_open else None

    with ThreadPoolExecutor(max_workers=48) as pool:
        futures = []
        queued = 0
        for subnet in subnets:
            network = ipaddress.ip_network(subnet, strict=False)
            host_count = max(0, network.num_addresses - 2)
            if host_count > MAX_DISCOVERY_HOSTS:
                job.log(f"Discovery pass on {network} limited to first {MAX_DISCOVERY_HOSTS} hosts for safety. Narrow the subnet for a full sweep.")
            else:
                job.log(f"Discovery pass on {network}")
            for ip in network.hosts():
                if queued >= MAX_DISCOVERY_HOSTS:
                    break
                ip_s = str(ip)
                if ip_s in listed_ips:
                    continue
                futures.append(pool.submit(probe, ip_s))
                queued += 1
        for fut in as_completed(futures):
            try:
                cand = fut.result()
            except Exception:
                continue
            if not cand:
                continue
            candidates[cand.ip] = cand

    discovered = sorted(candidates.values(), key=lambda c: tuple(int(x) for x in c.ip.split(".")))
    if discovered:
        job.log(f"Found {len(discovered)} additional likely switches that were not in the original list.")
    return discovered


def run_job(job: ScanJob) -> None:
    job.status = "running"
    try:
        workers = max(1, min(int(job.scan_concurrency or DEFAULT_SCAN_CONCURRENCY), MAX_SCAN_CONCURRENCY))
        job.log(f"Scanning concurrency set to {workers} worker(s).")
        with ThreadPoolExecutor(max_workers=workers) as pool:
            futures = {
                pool.submit(
                    scan_target,
                    job,
                    host,
                    port,
                    job.vendor_choice,
                    job.entered_username,
                    job.entered_password,
                    job.sections,
                ): (host, port)
                for host, port in job.listed_targets
            }
            for fut in as_completed(futures):
                host, port = futures[fut]
                try:
                    result = fut.result()
                except Exception as exc:
                    result = ScanResult(
                        ip=host,
                        port=port,
                        vendor="unknown",
                        success=False,
                        error=str(exc),
                        checked_at=datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                    )
                    job.log(f"[{host}] Unhandled worker error: {exc}")
                job.results.append(result)
        job.discovery_candidates = discover_candidates(job)
        job.status = "awaiting_discovery" if job.discovery_candidates else "complete"
    except Exception as exc:
        job.status = "error"
        job.log(f"Unhandled error: {exc}\n{traceback.format_exc()}")
    finally:
        if job.status in {"complete", "awaiting_discovery", "error"}:
            save_job_history(job)




def reapply_validation(job: ScanJob) -> None:
    for result in job.results:
        interfaces = result.parsed.get("interfaces") or parse_interfaces(result)
        result.parsed["interfaces"] = interfaces
        base_findings = [f for f in result.findings if (f.category or "") != "compliance"]
        compliance = [infer_finding_guidance(f, result) for f in apply_baseline_validation(job, result, interfaces)]
        result.findings = base_findings + compliance


def findings_summary(job: ScanJob) -> dict[str, int]:
    counts = {"critical": 0, "warning": 0, "info": 0}
    for result in job.results:
        for finding in result.findings:
            sev = (finding.severity or "info").lower()
            counts[sev] = counts.get(sev, 0) + 1
    return counts


def finding_to_dict(f: Finding) -> dict[str, Any]:
    return {"severity": f.severity, "category": f.category, "summary": f.summary, "port": f.port, "evidence": f.evidence, "likely_cause": f.likely_cause, "recommended_action": f.recommended_action, "remediation": f.remediation}


def result_to_dict(r: ScanResult) -> dict[str, Any]:
    raw_sections = r.sections or {}
    config_text = ""
    for section_name, commands in raw_sections.items():
        if section_name.lower() in {"system", "showtech"}:
            for cmd, output in commands.items():
                if "running-config" in cmd or "show tech" in cmd or "show support" in cmd or "show config" in cmd:
                    config_text += f"\n## {cmd}\n{output}\n"
    if not config_text:
        for section_name, commands in raw_sections.items():
            for cmd, output in commands.items():
                if "show running-config" in cmd:
                    config_text += f"\n## {cmd}\n{output}\n"
    return {
        "ip": r.ip,
        "port": r.port,
        "vendor": r.vendor,
        "hostname": r.hostname,
        "auth_note": r.auth_note,
        "sections": raw_sections,
        "parsed": r.parsed or {},
        "findings": [finding_to_dict(f) for f in r.findings],
        "success": r.success,
        "error": r.error,
        "checked_at": r.checked_at,
        "config_text": config_text.strip(),
        "config_hash": hashlib.sha256(config_text.encode("utf-8", errors="ignore")).hexdigest() if config_text else "",
    }


def candidate_to_dict(c: DiscoveryCandidate) -> dict[str, Any]:
    return {
        "ip": c.ip,
        "hostname": c.hostname,
        "discovered_by": c.discovered_by,
        "suspected_vendor": c.suspected_vendor,
        "ssh_open": c.ssh_open,
        "ssh_banner": c.ssh_banner,
        "confidence": c.confidence,
        "selected": c.selected,
    }


def job_snapshot(job: ScanJob) -> dict[str, Any]:
    return {
        "job_id": job.job_id,
        "created_at": job.created_at,
        "status": job.status,
        "listed_targets": [{"host": host, "port": port} for host, port in job.listed_targets],
        "sections": list(job.sections),
        "vendor_choice": job.vendor_choice,
        "enable_discovery": job.enable_discovery,
        "discovery_subnet": job.discovery_subnet,
        "enable_show_tech": job.enable_show_tech,
        "enable_port_map": job.enable_port_map,
        "baseline_profile": job.baseline_profile,
        "custom_required_vlans": list(job.custom_required_vlans),
        "custom_require_aaa": job.custom_require_aaa,
        "custom_require_snmp": job.custom_require_snmp,
        "custom_require_dot1x": job.custom_require_dot1x,
        "summary": findings_summary(job),
        "log_lines": list(job.log_lines),
        "results": [result_to_dict(r) for r in job.results],
        "discovery_candidates": [candidate_to_dict(c) for c in job.discovery_candidates],
    }


def save_job_history(job: ScanJob) -> Path:
    job_dir = HISTORY_JOBS_DIR / job.job_id
    job_dir.mkdir(parents=True, exist_ok=True)
    snap = job_snapshot(job)
    (job_dir / "job_snapshot.json").write_text(json.dumps(snap, indent=2), encoding="utf-8")
    (job_dir / "job_log.txt").write_text("\n".join(job.log_lines), encoding="utf-8", errors="ignore")
    for result in snap["results"]:
        safe_name = re.sub(r"[^A-Za-z0-9._-]+", "_", (result.get("hostname") or result.get("ip") or "switch"))[:80]
        switch_dir = job_dir / "switches" / safe_name
        switch_dir.mkdir(parents=True, exist_ok=True)
        (switch_dir / "result.json").write_text(json.dumps(result, indent=2), encoding="utf-8")
        if result.get("config_text"):
            (switch_dir / "config.txt").write_text(result["config_text"], encoding="utf-8", errors="ignore")
        switch_history_dir = HISTORY_SWITCH_DIR / safe_name
        switch_history_dir.mkdir(parents=True, exist_ok=True)
        (switch_history_dir / f"{job.job_id}.json").write_text(json.dumps(result, indent=2), encoding="utf-8")
    return job_dir


def list_history_jobs() -> list[dict[str, Any]]:
    items = []
    for snapshot in sorted(HISTORY_JOBS_DIR.glob('*/job_snapshot.json'), reverse=True):
        try:
            data = json.loads(snapshot.read_text(encoding='utf-8'))
        except Exception:
            continue
        items.append({
            "job_id": data.get("job_id", snapshot.parent.name),
            "created_at": data.get("created_at", snapshot.parent.name),
            "summary": data.get("summary", {}),
            "switch_count": len(data.get("results", [])),
            "vendor_choice": data.get("vendor_choice", "auto"),
            "path": str(snapshot),
        })
    return items


def load_history_job(job_id: str) -> dict[str, Any]:
    path = HISTORY_JOBS_DIR / job_id / 'job_snapshot.json'
    if not path.exists():
        raise HTTPException(status_code=404, detail='History snapshot not found')
    return json.loads(path.read_text(encoding='utf-8'))


def compare_snapshots(left: dict[str, Any], right: dict[str, Any]) -> dict[str, Any]:
    def key_findings(snapshot: dict[str, Any]) -> set[tuple[str, str, str, str]]:
        keys = set()
        for result in snapshot.get('results', []):
            host = result.get('hostname') or result.get('ip')
            for finding in result.get('findings', []):
                keys.add((host, finding.get('severity','info'), finding.get('port',''), finding.get('summary','')))
        return keys

    left_keys = key_findings(left)
    right_keys = key_findings(right)
    new_findings = sorted(right_keys - left_keys)
    resolved_findings = sorted(left_keys - right_keys)
    persistent_findings = sorted(left_keys & right_keys)

    left_results = { (r.get('hostname') or r.get('ip')): r for r in left.get('results', []) }
    right_results = { (r.get('hostname') or r.get('ip')): r for r in right.get('results', []) }
    config_changes = []
    for host in sorted(set(left_results) & set(right_results)):
        lres = left_results[host]
        rres = right_results[host]
        if lres.get('config_hash') != rres.get('config_hash'):
            diff_lines = list(difflib.unified_diff(
                (lres.get('config_text') or '').splitlines(),
                (rres.get('config_text') or '').splitlines(),
                fromfile=f"{left.get('job_id')}:{host}",
                tofile=f"{right.get('job_id')}:{host}",
                lineterm='',
            ))
            config_changes.append({
                'host': host,
                'ip': rres.get('ip') or lres.get('ip'),
                'vendor': rres.get('vendor') or lres.get('vendor'),
                'diff_preview': '\n'.join(diff_lines[:120]) if diff_lines else 'Configuration changed.',
            })

    return {
        'left': left,
        'right': right,
        'new_findings': new_findings,
        'resolved_findings': resolved_findings,
        'persistent_findings': persistent_findings,
        'config_changes': config_changes,
    }


def export_history_zip() -> bytes:
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, 'w', zipfile.ZIP_DEFLATED) as zf:
        for path in HISTORY_DIR.rglob('*'):
            if path.is_file():
                zf.write(path, arcname=str(path.relative_to(HISTORY_DIR)))
    return buf.getvalue()


def import_history_zip(data: bytes) -> int:
    count = 0
    history_root = HISTORY_DIR.resolve()
    with zipfile.ZipFile(io.BytesIO(data), 'r') as zf:
        for info in zf.infolist():
            if info.is_dir():
                continue
            target = (HISTORY_DIR / info.filename).resolve()
            if history_root not in target.parents and target != history_root:
                continue
            target.parent.mkdir(parents=True, exist_ok=True)
            with zf.open(info) as src, target.open('wb') as dst:
                dst.write(src.read())
            count += 1
    return count


def grouped_findings(job: ScanJob) -> list[dict[str, Any]]:
    ordered: list[dict[str, Any]] = []
    severity_rank = {"critical": 0, "warning": 1, "info": 2}
    for result in sorted(job.results, key=lambda r: (r.hostname or r.ip, r.ip)):
        findings = sorted(result.findings, key=lambda f: (severity_rank.get((f.severity or 'info').lower(), 9), f.category, f.port, f.summary))
        ordered.append({
            "result": result,
            "findings": findings,
            "counts": {
                "critical": sum(1 for f in findings if (f.severity or '').lower() == 'critical'),
                "warning": sum(1 for f in findings if (f.severity or '').lower() == 'warning'),
                "info": sum(1 for f in findings if (f.severity or '').lower() == 'info'),
            },
        })
    return ordered


# ---------------- Port Map / LLDP Renamer ----------------

def classify_neighbor_device(name: str) -> str:
    upper = (name or "").upper()
    if "AP" in upper or "WAP" in upper or "OMADA" in upper or "ACCESS POINT" in upper:
        return "Access Point"
    if "FW" in upper or "FIREWALL" in upper:
        return "Firewall"
    if "GATEWAY" in upper or upper.startswith("RTR") or "RTR-" in upper or "ROUTER" in upper:
        return "Gateway"
    if "SW" in upper or "SWITCH" in upper or "IDF" in upper or "MDF" in upper:
        return "Switch"
    return "Unknown"


def is_physical_infrastructure_neighbor(device_type: str) -> bool:
    return (device_type or "") in {"Switch", "Firewall", "Gateway"}


def port_map_switch_role(neighbor_name: str) -> str:
    upper = (neighbor_name or "").upper()
    if "RTR-" in upper or upper.startswith("RTR"):
        return "RTR"
    if "MDF" in upper:
        return "MDF"
    match = re.search(r"(IDF\d+|IDF)", upper)
    if match:
        return match.group(1)
    parts = [p for p in upper.split("-") if p]
    if len(parts) >= 3:
        tail = parts[-1]
        if tail and tail != "MDF" and not tail.startswith("IDF"):
            return tail[:10]
    return "SW"


def port_map_direction(neighbor_name: str) -> str:
    upper = (neighbor_name or "").upper()
    if "MDF" in upper or "RTR-" in upper or upper.startswith("RTR"):
        return "UL"
    if "IDF" in upper:
        return "DL"
    return "LINK"


def port_map_is_lag(device_type: str, neighbor_name: str, port_description: str = "") -> str:
    upper = f"{neighbor_name} {port_description}".upper()
    if device_type == "Switch" or "LAG" in upper or "PORT-CHANNEL" in upper or "TRK" in upper:
        return "Yes"
    return "No"


def build_port_map_name(neighbor_name: str, device_type: str, is_lag: str) -> str:
    upper = (neighbor_name or "").upper().strip()
    ap_match = re.search(r"AP[-_ ]?(\d{1,4})", upper)
    if ap_match:
        ap_num = ap_match.group(1).zfill(3)
        parts = [p for p in re.split(r"[-_\s]+", upper) if p]
        suffix = ""
        if len(parts) >= 3:
            building = parts[-2].title().replace(" ", "")
            room = parts[-1]
            if building or room:
                suffix = f"-{building}_{room}".rstrip("_")
        return sanitize_port_name(f"AP_{ap_num}{suffix}")
    if upper.startswith("RTR") or "RTR-" in upper:
        return "SW_RTR"
    if "MDF" in upper:
        return "SW_MDF"
    idf_match = re.search(r"(IDF\d+|IDF)", upper)
    if idf_match:
        return f"SW_{idf_match.group(1)}"
    parts = [p for p in re.split(r"[-_\s]+", upper) if p]
    if parts:
        return sanitize_port_name(f"SW_{parts[-1][:16]}")
    return "NEIGHBOR"


def sanitize_port_name(value: str) -> str:
    cleaned = re.sub(r"[^A-Za-z0-9._/-]+", "_", (value or "").strip())
    cleaned = re.sub(r"_+", "_", cleaned).strip("_")
    return cleaned[:64] or "NEIGHBOR"


def compare_port_names(existing_name: str, proposed_name: str) -> str:
    existing = (existing_name or "").strip()
    proposed = (proposed_name or "").strip()
    if not existing or existing.lower() == "empty":
        return "Needs Name"
    if existing.lower() == proposed.lower():
        return "Correct"
    if existing.lower().startswith(proposed.lower()) or proposed.lower().startswith(existing.lower()):
        return "Similar"
    return "Mismatch"



CISCO_PORT_TOKEN_RE = re.compile(r"(?:Gi|Te|Fa|Fo|Tw|Hu|Eth|Po)\d+(?:/\d+){0,2}", re.I)


def normalize_cisco_port(value: str) -> str:
    return (value or "").strip()


def parse_cisco_interface_status_rows(text: str) -> dict[str, dict[str, Any]]:
    """Parse Cisco `show interface status` rows.

    Cisco Name can contain spaces and quotes, so parse from both ends:
      Port Name Status Vlan Duplex Speed Type
      Gi1/0/7 YVRJWAP01 connected trunk a-full a-1000 10/100/1000BaseTX
    """
    interfaces: dict[str, dict[str, Any]] = {}
    status_words = {"connected", "notconnect", "disabled", "err-disabled", "inactive", "monitoring", "suspended"}
    clean = clean_output(text)
    for raw in clean.splitlines():
        line = raw.rstrip()
        if not line or line.lower().startswith("port ") or line.lower().startswith("device id"):
            continue
        m = re.match(r"^(?P<port>(?:Gi|Te|Fa|Fo|Tw|Hu|Eth)\d+(?:/\d+){0,2}|Po\d+)\s+(?P<rest>.+)$", line, re.I)
        if not m:
            continue
        port = normalize_cisco_port(m.group("port"))
        rest = m.group("rest").strip()
        tokens = rest.split()
        status_idx = None
        for i, tok in enumerate(tokens):
            if tok.lower() in status_words:
                status_idx = i
                break
        if status_idx is None or len(tokens) < status_idx + 4:
            continue
        name = " ".join(tokens[:status_idx]).strip().strip('"')
        status = tokens[status_idx]
        vlan = tokens[status_idx + 1] if len(tokens) > status_idx + 1 else ""
        duplex = tokens[status_idx + 2] if len(tokens) > status_idx + 2 else ""
        speed = tokens[status_idx + 3] if len(tokens) > status_idx + 3 else ""
        iface_type = " ".join(tokens[status_idx + 4:]) if len(tokens) > status_idx + 4 else ""
        speed_mbps = None
        slow = speed.lower().replace("a-", "")
        if "10g" in slow:
            speed_mbps = 10000
        elif "1000" in slow or "1g" in slow:
            speed_mbps = 1000
        elif "100" in slow:
            speed_mbps = 100
        elif re.fullmatch(r"10", slow) or "10m" in slow:
            speed_mbps = 10
        interfaces[port] = {
            "port": port,
            "line": line.strip(),
            "name": name,
            "status": "up" if status.lower() == "connected" else status.lower(),
            "speed_mbps": speed_mbps,
            "duplex": "half" if "half" in duplex.lower() else ("full" if "full" in duplex.lower() else ""),
            "neighbor": name if any(k in name.lower() for k in INFRA_KEYWORDS) else "",
            "role": "infrastructure" if (vlan.lower() == "trunk" or port.lower().startswith(("te", "po")) or any(k in name.lower() for k in INFRA_KEYWORDS)) else "unknown",
            "errors": 0,
            "crc": 0,
            "vlan": vlan,
            "type": iface_type,
        }
    return interfaces


def parse_cisco_lldp_summary_lines(text: str) -> list[dict[str, str]]:
    """Parse Cisco `show lldp neighbors` table.

    Handles normal rows and the common no-space wrap from wide Device ID values:
      regDN 8150,MINET_692Gi3/0/12 120 B,T 0008.5d5c.651b
    """
    entries: list[dict[str, str]] = []
    clean = clean_output(text)
    for raw in clean.splitlines():
        line = raw.rstrip()
        if not line or line.lower().startswith(("device id", "capability codes", "total entries", "local intf")):
            continue
        m = re.search(r"(?P<local>(?:Gi|Te|Fa|Fo|Tw|Hu|Eth)\d+(?:/\d+){0,2}|Po\d+)\s+(?P<hold>\d+)\s+(?P<caps>[A-Z, ]*)\s+(?P<portid>\S+)\s*$", line, re.I)
        if not m:
            continue
        local = normalize_cisco_port(m.group("local"))
        neighbor_name = line[:m.start("local")].strip()
        if not neighbor_name:
            continue
        entries.append({
            "local_port": local,
            "neighbor_name": neighbor_name,
            "neighbor_port": m.group("portid").strip(),
            "mgmt_ip": "",
            "port_description": "",
            "capabilities": m.group("caps").strip(),
            "detail": line.strip(),
        })
    return entries


def parse_cisco_lldp_detail_blocks(text: str) -> list[dict[str, str]]:
    """Parse Cisco `show lldp neighbors detail` output."""
    entries: list[dict[str, str]] = []
    clean = clean_output(text)
    blocks = re.split(r"\n-{5,}\n(?=\s*Local Intf\s*:)", clean, flags=re.I)
    for block in blocks:
        local = re.search(r"Local Intf\s*:\s*(?P<port>\S+)", block, flags=re.I)
        if not local:
            continue
        local_port = normalize_cisco_port(local.group("port"))
        chassis = re.search(r"Chassis id\s*:\s*(?P<chassis>.+)", block, flags=re.I)
        port_id = re.search(r"Port id\s*:\s*(?P<portid>.+)", block, flags=re.I)
        port_desc = re.search(r"Port Description\s*:\s*(?P<desc>.+)", block, flags=re.I)
        name = re.search(r"System Name\s*:\s*(?P<name>.+)", block, flags=re.I)
        sys_desc = re.search(r"System Description\s*:\s*(?P<desc>.*?)(?:\n\s*Time remaining:|\n\s*System Capabilities:|\Z)", block, flags=re.I | re.S)
        mgmt = re.search(r"Management Addresses:\s*\n\s*IP:\s*(?P<ip>\d+\.\d+\.\d+\.\d+)", block, flags=re.I)
        mau = re.search(r"Media Attachment Unit type\s*:\s*(?P<mau>.+)", block, flags=re.I)
        vlan = re.search(r"Vlan ID\s*:\s*(?P<vlan>.+)", block, flags=re.I)
        pwr_req = re.search(r"Power Requested\s*:\s*(?P<req>\d+\s*mW)", block, flags=re.I)
        pwr_alloc = re.search(r"Power Allocated\s*:\s*(?P<alloc>\d+\s*mW)", block, flags=re.I)
        system_name = name.group("name").strip() if name else ""
        if "not advertised" in system_name.lower():
            system_name = chassis.group("chassis").strip() if chassis else ""
        entries.append({
            "local_port": local_port,
            "neighbor_name": system_name,
            "neighbor_port": port_id.group("portid").strip() if port_id else "",
            "mgmt_ip": mgmt.group("ip").strip() if mgmt else "",
            "port_description": port_desc.group("desc").strip() if port_desc else "",
            "system_description": " ".join(sys_desc.group("desc").split()) if sys_desc else "",
            "operational_mau": mau.group("mau").strip() if mau else "",
            "port_vlan": vlan.group("vlan").strip() if vlan else "",
            "chassis_id": chassis.group("chassis").strip() if chassis else "",
            "power_requested": pwr_req.group("req").strip() if pwr_req else "",
            "power_allocated": pwr_alloc.group("alloc").strip() if pwr_alloc else "",
            "detail": block.strip(),
        })
    return entries


def parse_lldp_detail_blocks(text: str) -> list[dict[str, str]]:
    """Parse Ruckus-style LLDP detail blocks.

    Expected examples:
      Local port: 1/1/23
        + System name: PVDLWSW02-02-MDF
        + Port description    : "GigabitEthernet1/2/1"
        + Management address (IPv4): 10.97.19.132
        + Operational MAU type   : 1000BaseT-FD
    """
    entries: list[dict[str, str]] = []
    clean = clean_output(text)
    blocks = re.split(r"\n(?=\s*Local port\s*:\s*)", clean, flags=re.I)
    for block in blocks:
        local = re.search(r"Local port\s*:\s*(?P<port>\S+)", block, flags=re.I)
        if not local:
            continue
        local_port = local.group("port").strip().rstrip("/")
        no_neigh = re.search(r"No neighbors on port", block, flags=re.I)
        system_name = re.search(r"System name\s*:\s*(?P<name>.+)", block, flags=re.I)
        port_desc = re.search(r"Port description\s*:\s*\"?(?P<desc>[^\"\n]+)\"?", block, flags=re.I)
        mgmt = re.search(r"Management address\s*\([^)]*\)\s*:\s*(?P<ip>\d+\.\d+\.\d+\.\d+)", block, flags=re.I)
        mau = re.search(r"Operational MAU type\s*:\s*(?P<mau>.+)", block, flags=re.I)
        vlan = re.search(r"Port VLAN ID\s*:\s*(?P<vlan>\S+)", block, flags=re.I)
        chassis = re.search(r"Chassis ID\s*\([^)]*\)\s*:\s*(?P<chassis>\S+)", block, flags=re.I)
        port_id = re.search(r"Port ID\s*\([^)]*\)\s*:\s*(?P<portid>\S+)", block, flags=re.I)
        if no_neigh and not system_name:
            entries.append({
                "local_port": local_port,
                "neighbor_name": "",
                "neighbor_port": "",
                "mgmt_ip": "",
                "port_description": "No neighbor",
                "detail": block.strip(),
            })
            continue
        neighbor_name = system_name.group("name").strip() if system_name else ""
        remote_desc = port_desc.group("desc").strip() if port_desc else ""
        entry = {
            "local_port": local_port,
            "neighbor_name": neighbor_name,
            "neighbor_port": remote_desc,
            "mgmt_ip": mgmt.group("ip").strip() if mgmt else "",
            "port_description": remote_desc,
            "operational_mau": mau.group("mau").strip() if mau else "",
            "port_vlan": vlan.group("vlan").strip() if vlan else "",
            "chassis_id": chassis.group("chassis").strip() if chassis else "",
            "port_id": port_id.group("portid").strip() if port_id else "",
            "detail": block.strip(),
        }
        if any(entry.values()):
            entries.append(entry)
    return entries



def parse_aruba_cx_lldp_summary_lines(text: str) -> list[dict[str, str]]:
    """Parse Aruba CX `show lldp neighbor-info` summary table.

    Typical columns:
      LOCAL-PORT  CHASSIS-ID  PORT-ID  PORT-DESC  TTL  SYS-NAME
    Some switch-to-switch rows may have a blank PORT-DESC, so the parser
    treats the final token as SYS-NAME and the second-to-last numeric token as TTL.
    """
    entries: list[dict[str, str]] = []
    clean = clean_output(text)
    for raw in clean.splitlines():
        line = raw.strip()
        if not re.match(r"^\d+/\d+/\d+\s+", line):
            continue
        parts = re.split(r"\s{2,}", line)
        if len(parts) < 4:
            continue
        local_port = parts[0].strip()
        neighbor_name = parts[-1].strip()
        # Ignore table headings or malformed rows.
        if not neighbor_name or neighbor_name.upper() in {"SYS-NAME", "TTL"}:
            continue
        ttl_index = None
        for idx in range(len(parts) - 2, 1, -1):
            if re.fullmatch(r"\d+", parts[idx].strip()):
                ttl_index = idx
                break
        neighbor_port = parts[2].strip() if len(parts) > 2 else ""
        port_description = ""
        if ttl_index is not None and ttl_index - 1 >= 3:
            port_description = parts[ttl_index - 1].strip()
        elif len(parts) >= 5:
            port_description = parts[3].strip()
        entries.append({
            "local_port": local_port,
            "neighbor_name": neighbor_name,
            "neighbor_port": neighbor_port,
            "mgmt_ip": "",
            "port_description": port_description,
            "chassis_id": parts[1].strip() if len(parts) > 1 else "",
            "port_id": neighbor_port,
            "detail": line,
        })
    return entries


def parse_aruba_cx_lldp_detail_blocks(text: str) -> list[dict[str, str]]:
    """Parse Aruba CX `show lldp neighbor-info detail` output."""
    entries: list[dict[str, str]] = []
    clean = clean_output(text)
    # Detail output uses separator lines and blocks beginning with `Port : x/y/z`.
    blocks = re.split(r"\n-{5,}\n(?=\s*Port\s*:)", clean, flags=re.I)
    for block in blocks:
        local = re.search(r"^\s*Port\s*:\s*(?P<port>\S+)", block, flags=re.I | re.M)
        if not local:
            continue
        local_port = local.group("port").strip()
        name = re.search(r"Neighbor System-Name\s*:\s*(?P<name>.+)", block, flags=re.I)
        desc = re.search(r"Neighbor System-Description\s*:\s*(?P<desc>.+)", block, flags=re.I)
        chassis = re.search(r"Neighbor Chassis-ID\s*:\s*(?P<chassis>\S+)", block, flags=re.I)
        mgmt = re.search(r"Neighbor Management-Address\s*:\s*(?P<ip>\d+\.\d+\.\d+\.\d+)", block, flags=re.I)
        port_id = re.search(r"Neighbor Port-ID\s*:\s*(?P<port>.+)", block, flags=re.I)
        port_desc = re.search(r"Neighbor Port-Desc\s*:\s*(?P<desc>.+)", block, flags=re.I)
        mau = re.search(r"Neighbor MAU type\s*:\s*(?P<mau>.+)", block, flags=re.I)
        vlan = re.search(r"Neighbor Port VLAN ID\s*:\s*(?P<vlan>.+)", block, flags=re.I)
        entries.append({
            "local_port": local_port,
            "neighbor_name": name.group("name").strip() if name else "",
            "neighbor_port": port_id.group("port").strip() if port_id else "",
            "mgmt_ip": mgmt.group("ip").strip() if mgmt else "",
            "port_description": port_desc.group("desc").strip() if port_desc else "",
            "system_description": desc.group("desc").strip() if desc else "",
            "operational_mau": mau.group("mau").strip() if mau else "",
            "port_vlan": vlan.group("vlan").strip() if vlan else "",
            "chassis_id": chassis.group("chassis").strip() if chassis else "",
            "detail": block.strip(),
        })
    return entries

def parse_procurve_lldp_detail_blocks(text: str) -> list[dict[str, str]]:
    """Parse ProCurve/ArubaOS-Switch LLDP detail blocks."""
    entries: list[dict[str, str]] = []
    clean = clean_output(text)
    blocks = re.split(r"\n(?=\s*Local Port\s*:\s*)", clean, flags=re.I)
    for block in blocks:
        local = re.search(r"Local Port\s*:\s*(?P<port>\S+)", block, flags=re.I)
        if not local:
            continue
        local_port = local.group("port").strip().upper()
        name = re.search(r"(?:SysName|System Name)\s*:\s*(?P<name>.+)", block, flags=re.I)
        port_id = re.search(r"(?:PortId|Port ID)\s*:\s*(?P<port>.+)", block, flags=re.I)
        port_descr = re.search(r"(?:PortDescr|Port Description)\s*:\s*(?P<desc>.+)", block, flags=re.I)
        mgmt = re.search(r"(?:Management Address|Address)\s*:\s*(?P<ip>\d+\.\d+\.\d+\.\d+)", block, flags=re.I)
        desc = re.search(r"(?:System Descr|System Description)\s*:\s*(?P<desc>.+)", block, flags=re.I)
        entries.append({
            "local_port": local_port,
            "neighbor_name": name.group("name").strip() if name else "",
            "neighbor_port": port_id.group("port").strip() if port_id else "",
            "mgmt_ip": mgmt.group("ip").strip() if mgmt else "",
            "port_description": port_descr.group("desc").strip() if port_descr else "",
            "detail": block.strip() or (desc.group("desc").strip() if desc else ""),
        })
    return entries

def parse_ruckus_lldp_table_line(line: str) -> dict[str, str] | None:
    """Parse Ruckus ICX LLDP summary/table rows.

    Ruckus table output is often space-compressed, for example:
      1/1/1 b479.c834.a6f0 b479.c834.a6f0 eth0 SEAWAP001-14-STower-1450

    We intentionally avoid carrying the local port and chassis MAC into the
    displayed neighbor name.  The useful neighbor display is the system name.
    """
    raw = line.strip()
    m = re.match(r"^(?P<local_port>\d+/\d+/\d+|lg\d+|lag\d+|mgmt\d+)\s+", raw, re.I)
    if not m:
        return None
    local_port = m.group("local_port")
    tokens = raw.split()
    if len(tokens) >= 5:
        neighbor_port = tokens[3]
        neighbor_name = " ".join(tokens[4:]).strip()
        return {
            "local_port": local_port,
            "neighbor_name": neighbor_name,
            "neighbor_port": neighbor_port,
            "port_description": neighbor_port,
            "detail": raw,
        }
    # Fallback for wider output with large spacing.
    remainder = raw[m.end():].strip()
    parts = re.split(r"\s{2,}", remainder)
    if len(parts) < 2:
        return None
    neighbor_name = parts[-1].strip()
    return {"local_port": local_port, "neighbor_name": neighbor_name, "port_description": "", "detail": raw}


def parse_existing_port_names(result: ScanResult) -> dict[str, str]:
    names: dict[str, str] = {}
    text = "\n".join(result.sections.get("ports", {}).values())
    if result.vendor == "cisco_ios":
        for port, item in parse_cisco_interface_status_rows(text).items():
            if item.get("name"):
                names[port] = str(item.get("name", "")).strip()
        return names
    for raw in text.splitlines():
        line = raw.rstrip()
        if not line.strip():
            continue
        first = line.split()[0] if line.split() else ""
        if not re.match(r"^(\d+/\d+/\d+|\d+/\d+|\d+|lg\d+|lag\d+)$", first, re.I):
            continue
        parts = re.split(r"\s{2,}", line.strip())
        if len(parts) >= 2:
            candidate = parts[-1].strip()
            if candidate.lower() not in {"up", "down", "full", "half", "auto", "none", "--"} and not re.match(r"^\d+(M|G)?$", candidate, re.I):
                names[first] = "" if candidate.lower() == "empty" else candidate
    return names


def collect_lldp_entries(result: ScanResult) -> list[dict[str, str]]:
    """Return normalized LLDP entries from all collected LLDP command output."""
    lldp_text = "\n".join(result.sections.get("lldp", {}).values())
    entries: list[dict[str, str]] = []

    if result.vendor == "ruckus":
        entries.extend(parse_lldp_detail_blocks(lldp_text))
    elif result.vendor == "aruba_cx":
        entries.extend(parse_aruba_cx_lldp_detail_blocks(lldp_text))
        entries.extend(parse_aruba_cx_lldp_summary_lines(lldp_text))
    elif result.vendor == "hp_procurve":
        entries.extend(parse_procurve_lldp_detail_blocks(lldp_text))
    elif result.vendor == "cisco_ios":
        entries.extend(parse_cisco_lldp_detail_blocks(lldp_text))
        entries.extend(parse_cisco_lldp_summary_lines(lldp_text))

    for entry in lldp_neighbor_lines(lldp_text):
        normalized = {
            "local_port": entry.get("local_port", "").strip().upper() if result.vendor == "hp_procurve" else entry.get("local_port", "").strip().rstrip("/"),
            "neighbor_name": entry.get("neighbor_name", "") or entry.get("system_name", "") or "Unknown neighbor",
            "neighbor_port": entry.get("neighbor_port", ""),
            "mgmt_ip": entry.get("mgmt_ip", ""),
            "port_description": entry.get("port_description", "") or entry.get("neighbor_port", ""),
            "detail": entry.get("detail", ""),
        }
        if normalized["local_port"]:
            entries.append(normalized)

    for raw in lldp_text.splitlines():
        lower = raw.lower().strip()
        if not lower or lower.startswith(("lcl port", "local port")) or "chassis id" in lower:
            continue
        parsed = parse_ruckus_lldp_table_line(raw)
        if parsed:
            entries.append(parsed)

    # Keep the best entry per local port. Prefer entries with a real system name,
    # then entries with a management IP, then summary-table entries.
    best: dict[str, dict[str, str]] = {}
    def score(e: dict[str, str]) -> int:
        n = (e.get("neighbor_name") or "").strip().lower()
        s = 0
        if n and n not in {"unknown", "unknown neighbor", "-"}:
            s += 50
        if e.get("mgmt_ip"):
            s += 20
        if e.get("neighbor_port"):
            s += 10
        if e.get("detail") and "system name" in e.get("detail", "").lower():
            s += 10
        return s
    for entry in entries:
        port = (entry.get("local_port") or "").strip()
        if result.vendor == "hp_procurve":
            port = port.upper()
            entry["local_port"] = port
        elif result.vendor == "cisco_ios":
            port = normalize_cisco_port(port)
            entry["local_port"] = port
        else:
            port = port.rstrip("/")
            entry["local_port"] = port
        if not port:
            continue
        existing = best.get(port)
        if not existing or score(entry) >= score(existing):
            best[port] = entry
    return list(best.values())


MAC_RE = re.compile(r"(?:[0-9a-fA-F]{4}\.[0-9a-fA-F]{4}\.[0-9a-fA-F]{4}|[0-9a-fA-F]{2}(?::[0-9a-fA-F]{2}){5}|[0-9a-fA-F]{2}(?:-[0-9a-fA-F]{2}){5})")


def mac_command_for_port(vendor: str, port: str) -> str:
    port = (port or "").strip()
    if vendor == "hp_procurve":
        return f"show mac-add {port}"
    if vendor == "aruba_cx":
        return f"sh mac-address-table interface {port}"
    if vendor == "ruckus":
        return f"sh mac-add ether {port}"
    if vendor == "cisco_ios":
        return f"show mac address dynamic interface {port}"
    return ""


def interface_lookup_key(vendor: str, port: str) -> str:
    port = (port or "").strip()
    if vendor == "hp_procurve":
        return port.upper()
    if vendor == "cisco_ios":
        return normalize_cisco_port(port)
    return port.rstrip("/")


def collect_port_map_mac_addresses(shell: SSHShell, result: ScanResult, job: ScanJob) -> None:
    """Collect per-port MAC tables for Port Map rows that are not switch links.

    This is intentionally tied to Port Map so normal health scans remain light.
    Switch-to-switch links are skipped because those MAC lists are usually large
    and not useful for edge mapping.
    """
    if not job.enable_port_map:
        return
    interfaces_list = result.parsed.get("interfaces") or parse_interfaces(result)
    result.parsed["interfaces"] = interfaces_list
    interfaces = {interface_lookup_key(result.vendor, str(item.get("port", ""))): item for item in interfaces_list if item.get("port")}
    entries = collect_lldp_entries(result)
    lldp_by_port = {interface_lookup_key(result.vendor, str(e.get("local_port", ""))): e for e in entries if e.get("local_port")}
    existing_names = parse_existing_port_names(result)
    all_ports = sorted(set(interfaces) | set(lldp_by_port) | {interface_lookup_key(result.vendor, p) for p in existing_names}, key=sort_port_label)
    scanned = 0
    for port in all_ports:
        entry = lldp_by_port.get(port, {})
        neighbor_name = (entry.get("neighbor_name") or interfaces.get(port, {}).get("neighbor") or "").strip()
        device_type = classify_neighbor_device(neighbor_name) if neighbor_name else ""
        if device_type == "Switch":
            continue
        cmd = mac_command_for_port(result.vendor, port)
        if not cmd:
            continue
        if scanned >= MAX_PORT_MAC_SCAN_COMMANDS:
            job.log(f"[{result.ip}] Port Map MAC collection capped at {MAX_PORT_MAC_SCAN_COMMANDS} ports.")
            break
        try:
            out = shell.run(cmd, initial_wait=0.6, quiet_limit=4, job=job)
            if out and not command_rejected(out):
                result.sections.setdefault("macs", {})[cmd] = out
                scanned += 1
        except Exception as exc:
            job.log(f"[{result.ip}] MAC lookup failed on {port}: {exc}")
    if scanned:
        job.log(f"[{result.ip}] Port Map MAC addresses collected on {scanned} non-switch port(s).")


def parse_mac_output(raw: str) -> tuple[list[str], list[str]]:
    macs: list[str] = []
    vlans: list[str] = []
    for line in (raw or "").splitlines():
        if not MAC_RE.search(line):
            continue
        for mac in MAC_RE.findall(line):
            norm = mac.lower()
            if norm not in macs:
                macs.append(norm)
        # Best-effort VLAN extraction: most vendor tables put VLAN in the first
        # numeric column on MAC rows. Ignore obvious port fragments.
        parts = line.split()
        for token in parts[:3]:
            cleaned = token.strip().strip(":")
            if cleaned.isdigit() and 1 <= int(cleaned) <= 4094:
                if cleaned not in vlans:
                    vlans.append(cleaned)
                break
    return macs, vlans


def macs_for_port(result: ScanResult, port: str) -> dict[str, Any]:
    cmd = mac_command_for_port(result.vendor, port)
    raw = result.sections.get("macs", {}).get(cmd, "")
    macs, vlans = parse_mac_output(raw)
    return {"macs": macs, "vlans": vlans, "raw": raw}

def build_port_map_rows(job: ScanJob) -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    occurrence: dict[str, int] = {}
    for result in sorted(job.results, key=lambda r: (r.hostname or r.ip, r.ip)):
        if not result.success:
            continue
        interfaces_list = result.parsed.get("interfaces") or parse_interfaces(result)
        result.parsed["interfaces"] = interfaces_list
        interfaces = {str(item.get("port", "")).strip(): item for item in interfaces_list if item.get("port")}
        existing_names = parse_existing_port_names(result)
        entries = collect_lldp_entries(result)
        lldp_by_port = {str(e.get("local_port", "")).strip(): e for e in entries if e.get("local_port")}
        all_ports = set(interfaces) | set(existing_names) | set(lldp_by_port)
        for local_port in sorted(all_ports, key=sort_port_label):
            iface = interfaces.get(local_port, {})
            entry = lldp_by_port.get(local_port, {})
            neighbor_name = (entry.get("neighbor_name") or iface.get("neighbor") or "").strip()
            has_neighbor = bool(neighbor_name and neighbor_name.lower() not in {"unknown", "unknown neighbor", "-"})
            device_type = classify_neighbor_device(neighbor_name) if has_neighbor else ""
            is_lag = port_map_is_lag(device_type, neighbor_name, entry.get("port_description", "")) if has_neighbor else ""
            proposed = ""
            if has_neighbor:
                proposed = build_port_map_name(neighbor_name, device_type, is_lag)
                if device_type == "Switch" and is_lag == "Yes" and not proposed.endswith("_LAG"):
                    proposed = sanitize_port_name(f"{proposed}_LAG")
                occurrence[neighbor_name.upper()] = occurrence.get(neighbor_name.upper(), 0) + 1
            existing = existing_names.get(local_port, "")
            status = compare_port_names(existing, proposed) if has_neighbor else "No Neighbor"
            mac_info = macs_for_port(result, local_port) if device_type != "Switch" else {"macs": [], "vlans": [], "raw": ""}
            vlan_value = iface.get("vlan", "") or (", ".join(mac_info.get("vlans", [])) if mac_info.get("vlans") else "")
            if has_neighbor and not existing and local_port in interfaces:
                status = "Needs Name"
            rows.append({
                "switch_key": result.ip,
                "hostname": result.hostname or result.ip,
                "switch_ip": result.ip,
                "ssh_port": result.port,
                "vendor": result.vendor,
                "local_port": local_port,
                "status": iface.get("status", ""),
                "speed_mbps": iface.get("speed_mbps") or "",
                "duplex": iface.get("duplex", ""),
                "neighbor_name": neighbor_name,
                "neighbor_port": entry.get("neighbor_port", ""),
                "neighbor_ip": entry.get("mgmt_ip", ""),
                "untagged_vlan": vlan_value,
                "mac_addresses": mac_info.get("macs", []),
                "mac_vlans": mac_info.get("vlans", []),
                "mac_count": len(mac_info.get("macs", [])),
                "mac_raw": mac_info.get("raw", ""),
                "port_description": entry.get("port_description", ""),
                "device_type": device_type or "No Neighbor",
                "switch_role": port_map_switch_role(neighbor_name) if has_neighbor else "",
                "link_direction": port_map_direction(neighbor_name) if has_neighbor else "",
                "is_lag": is_lag,
                "existing_name": existing,
                "proposed_name": proposed,
                "compare_result": status,
                "has_neighbor": has_neighbor,
                "is_duplicate": False,
                "detail": entry.get("detail", iface.get("line", "")),
            })
    duplicate_names = {k for k, count in occurrence.items() if count > 1 and k}
    for row in rows:
        row["is_duplicate"] = bool(row.get("neighbor_name")) and row["neighbor_name"].upper() in duplicate_names
        row["command_preview"] = " ; ".join(build_port_rename_commands(row["vendor"], row["local_port"], row["proposed_name"], preview=True)) if row.get("proposed_name") else ""
    return rows


def build_port_map_diagram(rows: list[dict[str, Any]]) -> dict[str, Any]:
    """Build interactive port-map graph data.

    Default view is intentionally quiet: switch/firewall/gateway links only.
    APs and edge devices are available as grouped summary nodes or individual
    nodes through UI toggles. This avoids the previous spaghetti diagram where
    every AP created a separate long physical edge.
    """
    neighbor_rows = [r for r in rows if r.get("has_neighbor")]
    infra_rows = [r for r in neighbor_rows if is_physical_infrastructure_neighbor(str(r.get("device_type", "")))]
    ap_rows = [r for r in neighbor_rows if r.get("device_type") == "Access Point"]
    edge_rows = [r for r in neighbor_rows if r not in infra_rows and r not in ap_rows]

    def switch_id(row: dict[str, Any]) -> str:
        return "sw:" + str(row.get("switch_ip") or row.get("hostname") or "unknown")

    def neighbor_id(row: dict[str, Any]) -> str:
        key = row.get("neighbor_ip") or row.get("neighbor_name") or (str(row.get("switch_ip")) + ":" + str(row.get("local_port")))
        return "nb:" + str(key).upper()

    def edge_health(row: dict[str, Any]) -> tuple[str, list[str]]:
        issues: list[str] = []
        health = "healthy"
        speed = row.get("speed_mbps")
        try:
            speed_i = int(speed) if speed not in ("", None) else 0
        except Exception:
            speed_i = 0
        if speed_i and speed_i not in {1000, 10000}:
            issues.append(f"{speed_i}M link")
            health = "warning"
        if str(row.get("duplex", "")).lower() == "half":
            issues.append("half duplex")
            health = "critical"
        if row.get("is_duplicate"):
            issues.append("duplicate neighbor")
            if health != "critical":
                health = "warning"
        if row.get("compare_result") == "Mismatch":
            issues.append("name mismatch")
            if health != "critical":
                health = "warning"
        return health, issues

    nodes: dict[str, dict[str, Any]] = {}
    edges: list[dict[str, Any]] = []

    def add_switch(row: dict[str, Any]) -> None:
        sid = switch_id(row)
        nodes.setdefault(sid, {
            "id": sid,
            "label": f"{row.get('hostname') or row.get('switch_ip')}\n{row.get('switch_ip') or ''}",
            "title": f"Switch: {row.get('hostname') or row.get('switch_ip')}<br>IP: {row.get('switch_ip') or '-'}<br>Vendor: {row.get('vendor') or '-'}",
            "group": "switch",
            "rawType": "switch",
            "ip": row.get("switch_ip") or "",
            "hostname": row.get("hostname") or "",
            "shape": "box",
            "level": 0,
        })

    def add_neighbor(row: dict[str, Any], group: str, level: int = 2) -> str:
        nid = neighbor_id(row)
        device_type = row.get("device_type") or "Device"
        ip = row.get("neighbor_ip") or ""
        label = row.get("neighbor_name") or "Unknown neighbor"
        sub = ip or device_type
        nodes.setdefault(nid, {
            "id": nid,
            "label": f"{label}\n{sub}",
            "title": f"{device_type}: {label}<br>IP: {ip or '-'}<br>Remote port: {row.get('neighbor_port') or '-'}",
            "group": group,
            "rawType": device_type,
            "ip": ip,
            "hostname": label,
            "shape": "box",
            "level": level,
        })
        return nid

    # Infrastructure links are the default view.
    for row in infra_rows:
        add_switch(row)
        group = "gateway" if row.get("device_type") in {"Firewall", "Gateway"} else "switch"
        nid = add_neighbor(row, group, level=2)
        health, issues = edge_health(row)
        color = "#dc2626" if health == "critical" else ("#ea580c" if health == "warning" else "#2563eb")
        speed = row.get("speed_mbps") or ""
        label_bits = [str(row.get("local_port") or "?")]
        if row.get("neighbor_port"):
            label_bits.append("→ " + str(row.get("neighbor_port")))
        if speed:
            label_bits.append(f"({speed}M)")
        edges.append({
            "id": f"edge:{switch_id(row)}:{nid}:{row.get('local_port')}",
            "from": switch_id(row),
            "to": nid,
            "label": " ".join(label_bits),
            "title": f"{row.get('hostname')} {row.get('local_port')} → {row.get('neighbor_name')} {row.get('neighbor_port') or ''}<br>Speed: {speed or '-'}M<br>VLAN: {row.get('untagged_vlan') or '-'}<br>Issues: {', '.join(issues) if issues else 'None'}",
            "color": {"color": color, "highlight": color},
            "width": 4 if health == "critical" else (3 if health == "warning" else 2),
            "dashes": False,
            "linkClass": "infra",
            "health": health,
            "issues": issues,
            "localPort": row.get("local_port") or "",
            "neighborPort": row.get("neighbor_port") or "",
            "speedMbps": speed,
            "vlan": row.get("untagged_vlan") or "",
            "macCount": row.get("mac_count") or 0,
        })

    # Group APs and other endpoints by parent switch so expanded views are not spaghetti.
    grouped: dict[tuple[str, str], list[dict[str, Any]]] = {}
    for row in ap_rows:
        add_switch(row)
        grouped.setdefault((switch_id(row), "ap"), []).append(row)
    for row in edge_rows:
        add_switch(row)
        grouped.setdefault((switch_id(row), "edge"), []).append(row)

    for (sid, group_type), group_rows in grouped.items():
        if not group_rows:
            continue
        sw_label = group_rows[0].get("hostname") or group_rows[0].get("switch_ip") or "switch"
        gid = f"grp:{group_type}:{sid}"
        label = f"Access Points ({len(group_rows)})" if group_type == "ap" else f"Edge Devices ({len(group_rows)})"
        nodes[gid] = {
            "id": gid,
            "label": label,
            "title": f"{label} connected to {sw_label}. Toggle individual links for full detail.",
            "group": "ap_group" if group_type == "ap" else "edge_group",
            "rawType": "AP Summary" if group_type == "ap" else "Edge Summary",
            "shape": "box",
            "level": 1,
        }
        edges.append({
            "id": f"edge:{sid}:{gid}",
            "from": sid,
            "to": gid,
            "label": str(len(group_rows)),
            "title": f"{len(group_rows)} {'AP' if group_type == 'ap' else 'edge'} links from {sw_label}",
            "color": {"color": "#64748b", "highlight": "#475569"},
            "width": 2,
            "dashes": [6, 4],
            "linkClass": "ap_group" if group_type == "ap" else "edge_group",
            "health": "summary",
            "issues": [],
        })
        # Individual rows are available through toggles.
        for row in group_rows:
            row_group = "ap" if group_type == "ap" else "device"
            nid = add_neighbor(row, row_group, level=2)
            health, issues = edge_health(row)
            color = "#dc2626" if health == "critical" else ("#ea580c" if health == "warning" else ("#16a34a" if group_type == "ap" else "#94a3b8"))
            speed = row.get("speed_mbps") or ""
            edges.append({
                "id": f"edge:{sid}:{nid}:{row.get('local_port')}",
                "from": sid,
                "to": nid,
                "label": f"{row.get('local_port') or '?'}" + (f" ({speed}M)" if speed else ""),
                "title": f"{row.get('hostname')} {row.get('local_port')} → {row.get('neighbor_name')}<br>Speed: {speed or '-'}M<br>VLAN: {row.get('untagged_vlan') or '-'}<br>MACs: {row.get('mac_count') or 0}<br>Issues: {', '.join(issues) if issues else 'None'}",
                "color": {"color": color, "highlight": color},
                "width": 2,
                "dashes": group_type != "ap",
                "linkClass": "ap_detail" if group_type == "ap" else "edge_detail",
                "health": health,
                "issues": issues,
                "localPort": row.get("local_port") or "",
                "neighborPort": row.get("neighbor_port") or "",
                "speedMbps": speed,
                "vlan": row.get("untagged_vlan") or "",
                "macCount": row.get("mac_count") or 0,
            })

    return {
        "graph": {"nodes": list(nodes.values()), "edges": edges},
        "switches": [],
        "neighbors": [],
        "edges": [],
        "width": 1200,
        "height": 700,
        "infra_link_count": len(infra_rows),
        "ap_link_count": len(ap_rows),
        "other_link_count": len(edge_rows),
    }

def build_port_rename_commands(vendor: str, port: str, proposed_name: str, preview: bool = False) -> list[str]:
    name = sanitize_port_name(proposed_name)
    if vendor == "ruckus":
        return [f"interface eth {port}", f"port-name {name}"] if preview else ["config t", f"interface eth {port}", f"port-name {name}", "end", "write mem"]
    if vendor == "aruba_cx":
        return [f"interface {port}", f"description {name}"] if preview else ["configure terminal", f"interface {port}", f"description {name}", "end", "write memory"]
    if vendor == "hp_procurve":
        return [f"port {port} name {name}"] if preview else ["config", f"port {port} name {name}", "end", "write memory"]
    if vendor == "cisco_ios":
        return [f"interface {port}", f"description {name}"] if preview else ["configure terminal", f"interface {port}", f"description {name}", "end", "write memory"]
    if vendor == "tplink_media_panel":
        tplink_port = port if port.lower().startswith("gigabit") else f"gigabitEthernet {port}"
        return [f"interface {tplink_port}", f"description {name}"] if preview else ["configure terminal", f"interface {tplink_port}", f"description {name}", "exit", "end", "copy running-config startup-config"]
    return [f"! Unsupported vendor {vendor}; set port {port} name to {name}"]

def push_port_map_rows(job: ScanJob, rows: list[dict[str, Any]]) -> list[str]:
    logs: list[str] = []
    by_switch: dict[str, list[dict[str, Any]]] = {}
    for row in rows:
        by_switch.setdefault(row["switch_ip"], []).append(row)
    for ip, switch_rows in by_switch.items():
        first = switch_rows[0]
        shell = SSHShell(ip, int(first.get("ssh_port") or 22), timeout=12)
        try:
            shell.connect(first.get("vendor", "auto"), job.entered_username, job.entered_password, job)
            shell.maybe_enable(first.get("vendor", "unknown"), job.entered_password)
            commands: list[str] = []
            for row in switch_rows:
                commands.extend(build_port_rename_commands(row.get("vendor", "unknown"), row.get("local_port", ""), row.get("proposed_name", ""), preview=False))
            # Reduce repeated mode entry/save commands when multiple rows target the same switch.
            compact: list[str] = []
            in_config_added = False
            save_needed = False
            for cmd in commands:
                low = cmd.lower()
                if low in {"configure terminal", "conf t", "config", "config t"}:
                    if not in_config_added:
                        compact.append(cmd)
                        in_config_added = True
                elif low in {"write memory", "write mem", "wr mem", "copy running-config startup-config"}:
                    save_needed = True
                elif low == "end":
                    continue
                else:
                    compact.append(cmd)
            compact.append("end")
            if save_needed:
                compact.append("write mem" if first.get("vendor") == "ruckus" else ("copy running-config startup-config" if first.get("vendor") == "tplink_media_panel" else "write memory"))
            logs.append(f"[{ip}] Pushing {len(switch_rows)} port-name update(s).")
            for cmd in compact:
                out = shell.run(cmd, initial_wait=0.45, quiet_limit=3, job=job)
                if command_rejected(out):
                    logs.append(f"[{ip}] Command may have failed: {cmd} -> {out[:160]}")
            logs.append(f"[{ip}] Port-name update complete.")
        except Exception as exc:
            logs.append(f"[{ip}] Port map push failed: {exc}")
        finally:
            shell.close()
    return logs


@app.get("/health")
def health() -> dict[str, str]:
    return {"app": APP_NAME, "version": APP_VERSION}


@app.get("/", response_class=HTMLResponse)
def index(request: Request) -> HTMLResponse:
    return TEMPLATES.TemplateResponse(request, "index.html", {"request": request, "app_banner": APP_BANNER, "default_port": DEFAULT_PORT, "app_version": APP_VERSION, "default_scan_concurrency": DEFAULT_SCAN_CONCURRENCY, "max_scan_concurrency": MAX_SCAN_CONCURRENCY})


@app.post("/start")
def start_scan(
    request: Request,
    targets: str = Form(""),
    username: str = Form(...),
    password: str = Form(...),
    vendor: str = Form("auto"),
    sections: list[str] | None = Form(None),
    enable_discovery: str | None = Form(None),
    enable_show_tech: str | None = Form(None),
    enable_port_map: str | None = Form(None),
    port_map_subnet: str = Form(""),
    discovery_subnet: str = Form(""),
    scan_concurrency: int = Form(DEFAULT_SCAN_CONCURRENCY),
    enable_debug: str | None = Form(None),
):
    parsed_targets = parse_targets(targets) if targets.strip() else []
    port_map_subnet = (port_map_subnet or "").strip()
    if enable_port_map and port_map_subnet:
        subnet_targets = expand_subnet_targets(port_map_subnet, DEFAULT_PORT)
        existing = set(parsed_targets)
        parsed_targets.extend([t for t in subnet_targets if t not in existing])
    if not parsed_targets:
        raise HTTPException(status_code=400, detail="Provide targets or enable Port Map and enter a Port Map subnet.")
    sections_clean = ensure_list(sections, bool(enable_show_tech))
    if enable_port_map:
        for required_section in ("system", "ports", "lldp"):
            if required_section not in sections_clean:
                sections_clean.append(required_section)
    scan_concurrency = max(1, min(int(scan_concurrency or DEFAULT_SCAN_CONCURRENCY), MAX_SCAN_CONCURRENCY))
    job_id = datetime.now().strftime("%Y%m%d_%H%M%S")
    job = ScanJob(
        job_id=job_id,
        created_at=datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        listed_targets=parsed_targets,
        sections=sections_clean,
        entered_username=username.strip(),
        entered_password=password,
        vendor_choice=vendor,
        enable_discovery=bool(enable_discovery),
        discovery_subnet=discovery_subnet.strip(),
        enable_show_tech=bool(enable_show_tech),
        enable_port_map=bool(enable_port_map),
        port_map_subnet=port_map_subnet,
        scan_concurrency=scan_concurrency,
        enable_debug=bool(enable_debug),
        baseline_profile="none",
        custom_required_vlans=[],
        custom_require_aaa=False,
        custom_require_snmp=False,
        custom_require_dot1x=False,
    )
    job.log(f"Application started - {APP_BANNER}")
    job.log(f"Starting listed-target checks for {len(parsed_targets)} switch(es) with concurrency {scan_concurrency}")
    job.log("Baseline validation can be applied after the scan completes.")
    if job.enable_show_tech:
        job.log("Show tech option enabled. This may take a long time on some switches.")
    if job.enable_debug:
        job.log("Debug logging enabled. Full command/error details will be written to the debug log file.")
    if job.enable_port_map:
        job.log("Port map option enabled. Neighbor discovery and naming preview data will be collected.")
        if job.port_map_subnet:
            job.log(f"Port map subnet added to scan targets: {job.port_map_subnet}")
    with jobs_lock:
        jobs[job_id] = job
    threading.Thread(target=run_job, args=(job,), daemon=True).start()
    return RedirectResponse(url=f"/job/{job_id}", status_code=303)


@app.get("/job/{job_id}", response_class=HTMLResponse)
def view_job(request: Request, job_id: str) -> HTMLResponse:
    job = jobs.get(job_id)
    if not job:
        raise HTTPException(status_code=404, detail="Job not found")
    return TEMPLATES.TemplateResponse(request, "job.html", {"request": request, "job": job, "app_banner": APP_BANNER, "vendor_aliases": VENDOR_ALIASES, "baseline_profiles": BASELINE_PROFILES, "app_version": APP_VERSION})


@app.post("/job/{job_id}/investigate")
def investigate_candidates(
    request: Request,
    job_id: str,
    selected_ips: list[str] | None = Form(None),
    credential_mode: str = Form("current"),
    new_username: str = Form(""),
    new_password: str = Form(""),
):
    job = jobs.get(job_id)
    if not job:
        raise HTTPException(status_code=404, detail="Job not found")
    selected = set(selected_ips or [])
    if not selected:
        return RedirectResponse(url=f"/job/{job_id}", status_code=303)

    username = job.entered_username if credential_mode == "current" else new_username.strip()
    password = job.entered_password if credential_mode == "current" else new_password
    if not username or not password:
        raise HTTPException(status_code=400, detail="Credentials are required to investigate discovered devices.")

    for candidate in job.discovery_candidates:
        if candidate.ip in selected:
            candidate.selected = True

    chosen = [c for c in job.discovery_candidates if c.selected]
    job.log(f"User chose to investigate {len(chosen)} discovered device(s).")
    workers = max(1, min(int(job.scan_concurrency or DEFAULT_SCAN_CONCURRENCY), MAX_SCAN_CONCURRENCY))
    with ThreadPoolExecutor(max_workers=workers) as pool:
        futures = {}
        for candidate in chosen:
            vendor_hint = candidate.suspected_vendor if candidate.suspected_vendor in VENDOR_PROFILES else "auto"
            futures[pool.submit(scan_target, job, candidate.ip, 22, vendor_hint, username, password, job.sections)] = candidate.ip
        for fut in as_completed(futures):
            ip = futures[fut]
            try:
                result = fut.result()
            except Exception as exc:
                result = ScanResult(ip=ip, port=22, vendor="unknown", success=False, error=str(exc), checked_at=datetime.now().strftime("%Y-%m-%d %H:%M:%S"))
                job.log(f"[{ip}] Unhandled worker error: {exc}")
            job.results.append(result)
    job.status = "complete"
    save_job_history(job)
    return RedirectResponse(url=f"/job/{job_id}", status_code=303)




@app.post("/job/{job_id}/apply-validation")
def apply_validation(job_id: str, baseline_profile: str = Form("none"), custom_required_vlans: str = Form(""), custom_require_aaa: str | None = Form(None), custom_require_snmp: str | None = Form(None), custom_require_dot1x: str | None = Form(None)):
    job = jobs.get(job_id)
    if not job:
        raise HTTPException(status_code=404, detail="Job not found")
    job.baseline_profile = baseline_profile if baseline_profile in BASELINE_PROFILES else "none"
    job.custom_required_vlans = [int(x.strip()) for x in re.split(r"[,\s]+", custom_required_vlans.strip()) if x.strip().isdigit()]
    job.custom_require_aaa = bool(custom_require_aaa)
    job.custom_require_snmp = bool(custom_require_snmp)
    job.custom_require_dot1x = bool(custom_require_dot1x)
    reapply_validation(job)
    if job.baseline_profile == "none":
        job.log("Baseline validation cleared for this job.")
    else:
        job.log(f"Baseline validation applied after scan: {BASELINE_PROFILES.get(job.baseline_profile, {}).get('label', job.baseline_profile)}")
    save_job_history(job)
    return RedirectResponse(url=f"/job/{job_id}/compliance", status_code=303)


@app.get("/job/{job_id}/findings", response_class=HTMLResponse)
def view_findings(request: Request, job_id: str) -> HTMLResponse:
    job = jobs.get(job_id)
    if not job:
        raise HTTPException(status_code=404, detail="Job not found")
    return TEMPLATES.TemplateResponse(
        request,
        "findings.html",
        {
            "request": request,
            "job": job,
            "app_banner": APP_BANNER,
            "vendor_aliases": VENDOR_ALIASES,
            "summary": findings_summary(job),
            "grouped": grouped_findings(job),
            "baseline_profiles": BASELINE_PROFILES,
            "app_version": APP_VERSION,
        },
    )


@app.get("/job/{job_id}/topology", response_class=HTMLResponse)
def view_topology(request: Request, job_id: str) -> HTMLResponse:
    job = jobs.get(job_id)
    if not job:
        raise HTTPException(status_code=404, detail="Job not found")
    topology = build_topology(job)
    return TEMPLATES.TemplateResponse(
        request,
        "topology.html",
        {
            "request": request,
            "job": job,
            "app_banner": APP_BANNER,
            "vendor_aliases": VENDOR_ALIASES,
            "topology": topology,
        },
    )


@app.get("/job/{job_id}/port-map", response_class=HTMLResponse)
def view_port_map(request: Request, job_id: str) -> HTMLResponse:
    job = jobs.get(job_id)
    if not job:
        raise HTTPException(status_code=404, detail="Job not found")
    rows = build_port_map_rows(job)
    diagram = build_port_map_diagram(rows)
    return TEMPLATES.TemplateResponse(
        request,
        "port_map.html",
        {
            "request": request,
            "job": job,
            "app_banner": APP_BANNER,
            "vendor_aliases": VENDOR_ALIASES,
            "rows": rows,
            "diagram": diagram,
            "push_logs": [],
            "app_version": APP_VERSION,
        },
    )


@app.post("/job/{job_id}/port-map/push", response_class=HTMLResponse)
def push_port_map(request: Request, job_id: str, selected_indexes: list[int] | None = Form(None)) -> HTMLResponse:
    job = jobs.get(job_id)
    if not job:
        raise HTTPException(status_code=404, detail="Job not found")
    rows = build_port_map_rows(job)
    selected = set(selected_indexes or [])
    rows_to_push = [row for idx, row in enumerate(rows) if idx in selected and row.get("proposed_name")]
    push_logs: list[str] = []
    if not rows_to_push:
        push_logs.append("No rows selected for push.")
    else:
        push_logs = push_port_map_rows(job, rows_to_push)
        for line in push_logs:
            job.log(line)
    diagram = build_port_map_diagram(rows)
    return TEMPLATES.TemplateResponse(
        request,
        "port_map.html",
        {
            "request": request,
            "job": job,
            "app_banner": APP_BANNER,
            "vendor_aliases": VENDOR_ALIASES,
            "rows": rows,
            "diagram": diagram,
            "push_logs": push_logs,
            "app_version": APP_VERSION,
        },
    )




@app.get("/job/{job_id}/compliance", response_class=HTMLResponse)
def view_compliance(request: Request, job_id: str) -> HTMLResponse:
    job = jobs.get(job_id)
    if not job:
        raise HTTPException(status_code=404, detail="Job not found")
    compliance_grouped = []
    for result in sorted(job.results, key=lambda r: (r.hostname or r.ip, r.ip)):
        compliance_findings = [f for f in result.findings if f.category == "compliance"]
        compliance_grouped.append({"result": result, "findings": compliance_findings})
    return TEMPLATES.TemplateResponse(
        request,
        "compliance.html",
        {
            "request": request,
            "job": job,
            "app_banner": APP_BANNER,
            "vendor_aliases": VENDOR_ALIASES,
            "baseline_profiles": BASELINE_PROFILES,
            "compliance_grouped": compliance_grouped,
            "app_version": APP_VERSION,
        },
    )


@app.get("/job/{job_id}/remediation", response_class=HTMLResponse)
def view_remediation(request: Request, job_id: str) -> HTMLResponse:
    job = jobs.get(job_id)
    if not job:
        raise HTTPException(status_code=404, detail="Job not found")
    plans = build_remediation_plan(job)
    return TEMPLATES.TemplateResponse(
        request,
        "remediation.html",
        {
            "request": request,
            "job": job,
            "app_banner": APP_BANNER,
            "vendor_aliases": VENDOR_ALIASES,
            "plans": plans,
            "baseline_profiles": BASELINE_PROFILES,
            "app_version": APP_VERSION,
        },
    )


@app.get("/history", response_class=HTMLResponse)
def history_page(request: Request) -> HTMLResponse:
    return TEMPLATES.TemplateResponse(
        request,
        "history.html",
        {
            "request": request,
            "app_banner": APP_BANNER,
            "history_jobs": list_history_jobs(),
            "vendor_aliases": VENDOR_ALIASES,
        },
    )


@app.get("/history/{job_id}", response_class=HTMLResponse)
def history_job_page(request: Request, job_id: str) -> HTMLResponse:
    snapshot = load_history_job(job_id)
    history_jobs = list_history_jobs()
    previous_job_id = ""
    for idx, item in enumerate(history_jobs):
        if item["job_id"] == job_id and idx + 1 < len(history_jobs):
            previous_job_id = history_jobs[idx + 1]["job_id"]
            break
    return TEMPLATES.TemplateResponse(
        request,
        "history_detail.html",
        {
            "request": request,
            "app_banner": APP_BANNER,
            "snapshot": snapshot,
            "vendor_aliases": VENDOR_ALIASES,
            "previous_job_id": previous_job_id,
        },
    )


@app.get("/history/compare/{left_job_id}/{right_job_id}", response_class=HTMLResponse)
def history_compare_page(request: Request, left_job_id: str, right_job_id: str) -> HTMLResponse:
    comparison = compare_snapshots(load_history_job(left_job_id), load_history_job(right_job_id))
    return TEMPLATES.TemplateResponse(
        request,
        "compare.html",
        {
            "request": request,
            "app_banner": APP_BANNER,
            "comparison": comparison,
            "vendor_aliases": VENDOR_ALIASES,
        },
    )


@app.get("/history/export")
def export_history():
    payload = export_history_zip()
    filename = f"switch_dashboard_history_{datetime.now().strftime('%Y%m%d_%H%M%S')}.zip"
    return StreamingResponse(
        io.BytesIO(payload),
        media_type="application/zip",
        headers={"Content-Disposition": f'attachment; filename="{filename}"'},
    )


@app.post("/history/import")
async def import_history(history_file: UploadFile = File(...)):
    data = await history_file.read()
    imported = import_history_zip(data)
    return RedirectResponse(url=f"/history?imported={imported}", status_code=303)


@app.get("/job/{job_id}/history-save")
def save_job_history_route(job_id: str):
    job = jobs.get(job_id)
    if not job:
        raise HTTPException(status_code=404, detail="Job not found")
    save_job_history(job)
    return RedirectResponse(url=f"/history/{job_id}", status_code=303)



@app.get("/job/{job_id}/debug-log")
def download_debug_log(job_id: str):
    debug_path = LOG_DIR / f"switch_dashboard_{job_id}_debug.log"
    if not debug_path.exists():
        raise HTTPException(status_code=404, detail="Debug log not found for this job")

    def iter_file():
        with debug_path.open("rb") as handle:
            while True:
                chunk = handle.read(65536)
                if not chunk:
                    break
                yield chunk

    return StreamingResponse(
        iter_file(),
        media_type="text/plain",
        headers={"Content-Disposition": f'attachment; filename="{debug_path.name}"'},
    )

@app.get("/job/{job_id}/export")
def export_job(job_id: str):
    job = jobs.get(job_id)
    if not job:
        raise HTTPException(status_code=404, detail="Job not found")
    wb = Workbook()
    ws = wb.active
    ws.title = "Findings"
    ws.append(["Hostname", "IP", "Vendor", "Severity", "Category", "Port", "Summary", "Evidence", "Auth Note"])
    for cell in ws[1]:
        cell.font = Font(bold=True)
        cell.fill = PatternFill(fill_type="solid", fgColor="D9EAF7")
    for result in job.results:
        if not result.findings:
            ws.append([result.hostname or result.ip, result.ip, result.vendor, "info", "scan", "", "No findings generated.", result.error or "", result.auth_note])
        else:
            for finding in result.findings:
                ws.append([
                    result.hostname or result.ip,
                    result.ip,
                    result.vendor,
                    finding.severity,
                    finding.category,
                    finding.port,
                    finding.summary,
                    finding.evidence,
                    result.auth_note,
                ])
    export_path = EXPORT_DIR / f"switch_health_dashboard_{job_id}.xlsx"
    wb.save(export_path)

    def iter_file():
        with export_path.open("rb") as handle:
            while True:
                chunk = handle.read(65536)
                if not chunk:
                    break
                yield chunk

    return StreamingResponse(
        iter_file(),
        media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        headers={"Content-Disposition": f'attachment; filename="{export_path.name}"'},
    )
