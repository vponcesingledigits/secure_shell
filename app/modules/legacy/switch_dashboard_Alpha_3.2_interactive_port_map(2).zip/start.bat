@echo off
setlocal

cd /d "%~dp0"

set APP_ROOT=%LOCALAPPDATA%\SwitchHealthDashboard
set VENV_DIR=%APP_ROOT%\venv

if not exist "%APP_ROOT%" mkdir "%APP_ROOT%"

if not exist "%VENV_DIR%\Scripts\python.exe" (
    py -3 -m venv "%VENV_DIR%"
)

call "%VENV_DIR%\Scripts\activate.bat"

python -m pip install --upgrade pip
python -m pip install -r requirements.txt

start "" http://127.0.0.1:8017
python -m uvicorn switch_dashboard:app --host 127.0.0.1 --port 8017
