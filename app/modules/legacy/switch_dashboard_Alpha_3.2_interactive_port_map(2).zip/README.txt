Switch Health Dashboard — Alpha 3.2 Unified UI
==============================================

What this build adds
--------------------
- Standard Single Digits favicon on every FastAPI page
- Unified Single Digits / ForeScout-style interface treatment
- Shared sidebar navigation and consistent cards, buttons, badges, and page headers
- Keeps the Alpha 3.2 workflow:
  - FastAPI web app
  - Non-admin Windows start.bat launcher
  - Findings page
  - Topology page
  - Post-scan compliance validation
  - Remediation command generator
  - History save / compare
  - Import / export history
  - Optional discovery of unlisted switches
  - Optional show tech / full investigation mode

Run on Windows
--------------
1. Extract the folder anywhere you can write to.
2. Double-click start.bat.
3. The launcher creates a private venv under %LOCALAPPDATA%\SwitchHealthDashboard if needed.
4. The app opens at http://127.0.0.1:8017

Notes
-----
- Switch SSH defaults to port 22.
- Web UI runs on 127.0.0.1:8017.
- History is stored under %LOCALAPPDATA%\SwitchHealthDashboard\History.
- Show tech can take a long time and generate very large outputs.


Alpha 3.2 efficiency cleanup
----------------------------
- Thread-safe session logging with a capped in-memory log buffer.
- Discovery subnet guardrail for very large ranges.
- Faster hostname detection and baseline validation on show-tech-heavy scans.
- Safer history import path handling.
- Faster topology flap lookup.

Alpha 3.2 Port Map addition
---------------------------
- Optional Port Map checkbox on the first page.
- When enabled, LLDP and port information are forced into the scan collection set.
- New Port Map page per job: /job/<job_id>/port-map
- Shows each local port with LLDP neighbor details, proposed port name, existing name when parsed, duplicate flags, and command preview.
- Optional Push Selected Port Names action uses vendor-aware commands and the job credentials.
- Review the preview before pushing. This is intended for controlled maintenance/change windows.

Alpha 3.2 Port Map robustness update
------------------------------------
- Port Map can now run from a subnet-only input on the home page.
- Port Map collects system, port, and neighbor data and lists every parsed port, not only ports with neighbors.
- The neighbor naming workflow is now part of Port Map rather than a separate LLDP tool.
- Port Map includes a Visio-style SVG neighbor diagram for quick visual review.
- Port-name updates remain optional and selected-row only.

Alpha 3.2 Aruba CXOS Port Map update
------------------------------------
- Aruba CXOS LLDP parsing now handles `show lldp neighbor-info` summary output.
- Aruba CXOS LLDP parsing now handles `show lldp neighbor-info detail` blocks.
- Aruba CXOS port map pulls neighbor system name, neighbor port, management IP, chassis ID, MAU type, VLAN hints, and raw evidence when available.
- Aruba CXOS port-name updates use:
  configure terminal
  interface <port>
  description <name>
  end
  write memory
- ProCurve port-name updates use `config`, `port <port> name <name>`, `end`, `write memory`.
- Ruckus port-name updates use `config t`, `interface eth <port>`, `port-name <name>`, `end`, `write mem`.


Alpha 3.2 Cisco Port Map additions
- Cisco IOS / Catalyst vendor profile
- Cisco interface status parsing from `show interface status`
- Cisco LLDP summary/detail parsing from `show lldp neighbors` and `show lldp neighbors detail`
- Cisco port rename preview/push commands using interface descriptions
- Cisco stacked interface names such as Gi1/0/7, Te3/0/1, Po1 supported in Port Map

Alpha 3.2 Port Map MAC/VLAN additions
- Port Map and Topology now include best-effort untagged/access VLAN visibility.
- For non-switch-facing ports, the tool collects per-port MAC addresses when supported.
- Switch-facing ports skip per-port MAC collection to avoid noisy trunk/uplink MAC tables.
- Vendor MAC lookup commands:
  - ProCurve: show mac-add <port>
  - Aruba CXOS: sh mac-address-table interface <port>
  - Ruckus ICX: sh mac-add ether <port>
  - Cisco IOS: show mac address dynamic interface <port>

Alpha 3.2 debug logging update
------------------------------
- Added optional Debug Logging checkbox on the scan form.
- Debug mode writes full command attempts, command output previews, SSH/login failures, and Python tracebacks to:
  %LOCALAPPDATA%\SwitchHealthDashboard\Logs\switch_dashboard_<job_id>_debug.log
- Paramiko internal SSH debug output is written separately when debug is enabled:
  %LOCALAPPDATA%\SwitchHealthDashboard\Logs\switch_dashboard_<job_id>_paramiko.log
- Passwords entered in the form are redacted from the app debug log.
- SSH banner failures now appear as a clean per-device error instead of a large console traceback during normal scans.

Alpha 3.2 interactive Port Map update
- Replaced static Visio-style SVG port map with an interactive vis-network graph.
- Default view shows only switch, firewall, and gateway/router infrastructure links.
- APs and edge devices are grouped by parent switch to reduce visual clutter.
- Optional toggles allow AP groups, individual AP links, edge groups, and individual edge links.
- Clicking nodes and links shows port, speed, VLAN, MAC count, and neighbor detail.
