import ipaddress
import re
import time
from dataclasses import dataclass, asdict
from typing import Dict, List, Optional, Set, Tuple

from fastapi import FastAPI, Form, Request
from fastapi.responses import HTMLResponse
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates

try:
    from netmiko import ConnectHandler
except Exception:  # pragma: no cover
    ConnectHandler = None

APP_TITLE = "Cisco Traffic Investigator Alpha 1.1"
FAVICON_URL = "https://images.squarespace-cdn.com/content/v1/63eaba56d2bc1c0edd1199e0/6c87c44f-feae-44b2-a096-fea952fde4bf/favicon.ico?format=100w"

app = FastAPI(title=APP_TITLE)
app.mount("/static", StaticFiles(directory="static"), name="static")
templates = Jinja2Templates(directory="templates")

COMMANDS = [
    "terminal length 0",
    "show version | include uptime|System serial|Model number|Cisco IOS",
    "show interfaces",
    "show interfaces status",
    "show interfaces counters errors",
    "show mac address-table",
    "show arp",
    "show cdp neighbors detail",
    "show lldp neighbors detail",
]

@dataclass
class NeighborInfo:
    local_interface: str
    device_id: str = ""
    remote_interface: str = ""
    management_ip: str = ""
    protocol: str = ""
    platform: str = ""

@dataclass
class InterfaceFinding:
    interface: str
    input_bps: int = 0
    output_bps: int = 0
    input_pps: int = 0
    output_pps: int = 0
    status: str = "unknown"
    vlan: str = ""
    duplex: str = ""
    speed: str = ""
    type: str = ""
    mac_count: int = 0
    sample_macs: str = ""
    sample_ips: str = ""
    neighbor: str = ""
    neighbor_ip: str = ""
    neighbor_remote_port: str = ""
    role_guess: str = ""
    severity: str = "normal"
    reason: str = ""
    traced: bool = False

@dataclass
class SwitchScan:
    target_ip: str
    hostname: str = ""
    depth: int = 0
    parent_ip: str = ""
    parent_interface: str = ""
    parent_neighbor: str = ""
    error: str = ""
    findings: List[InterfaceFinding] = None
    summary: List[str] = None
    raw: Dict[str, str] = None


def normalize_intf(name: str) -> str:
    n = name.strip().strip(',')
    replacements = {
        "GigabitEthernet": "Gi", "TenGigabitEthernet": "Te", "TwentyFiveGigE": "Twe",
        "FortyGigabitEthernet": "Fo", "HundredGigE": "Hu", "FastEthernet": "Fa",
        "Ethernet": "Et", "Port-channel": "Po", "Port-Channel": "Po",
        "Gig": "Gi", "Ten": "Te", "Fas": "Fa",
    }
    for long, short in replacements.items():
        if n.startswith(long):
            return n.replace(long, short, 1)
    return n


def human_bps(v: int) -> str:
    units = ["bps", "Kbps", "Mbps", "Gbps", "Tbps"]
    f = float(v or 0)
    for u in units:
        if f < 1000 or u == units[-1]:
            return f"{f:.1f} {u}" if u != "bps" else f"{int(f)} {u}"
        f /= 1000


def parse_hostname(outputs: Dict[str, str], fallback_ip: str) -> str:
    for out in outputs.values():
        m = re.search(r"\n([A-Za-z0-9_.-]+)[#>]\s*$", out or "")
        if m:
            return m.group(1)
    return fallback_ip


def parse_show_interfaces(output: str) -> Dict[str, Dict[str, int]]:
    data: Dict[str, Dict[str, int]] = {}
    current = None
    for line in output.splitlines():
        m = re.match(r"^(\S+(?:Ethernet|GigE|channel|Channel)\S*|[A-Z][a-z]*\d[/\d\.]+) is ", line)
        if m:
            current = normalize_intf(m.group(1))
            data.setdefault(current, {"input_bps": 0, "output_bps": 0, "input_pps": 0, "output_pps": 0})
            continue
        if not current:
            continue
        m = re.search(r"(?:5 minute |30 second )?input rate (\d+) bits/sec, (\d+) packets/sec", line)
        if m:
            data[current]["input_bps"] = int(m.group(1)); data[current]["input_pps"] = int(m.group(2))
        m = re.search(r"(?:5 minute |30 second )?output rate (\d+) bits/sec, (\d+) packets/sec", line)
        if m:
            data[current]["output_bps"] = int(m.group(1)); data[current]["output_pps"] = int(m.group(2))
    return data


def parse_status(output: str) -> Dict[str, Dict[str, str]]:
    status = {}
    for line in output.splitlines():
        if not line.strip() or line.lower().startswith(("port", "--")):
            continue
        parts = line.split()
        if len(parts) < 6:
            continue
        port = normalize_intf(parts[0])
        status[port] = {"type": parts[-1], "speed": parts[-2], "duplex": parts[-3], "vlan": parts[-4], "status": parts[-5]}
    return status


def parse_mac_table(output: str) -> Dict[str, List[str]]:
    by_port: Dict[str, List[str]] = {}
    for line in output.splitlines():
        m = re.search(r"\b([0-9a-fA-F]{4}\.[0-9a-fA-F]{4}\.[0-9a-fA-F]{4})\b.*?\s((?:Gi|Te|Fa|Eth|Et|Po|Twe|Fo|Hu)\S+)$", line.strip())
        if m:
            by_port.setdefault(normalize_intf(m.group(2)), []).append(m.group(1).lower())
    return by_port


def parse_arp(output: str) -> Dict[str, str]:
    arp = {}
    for line in output.splitlines():
        m = re.search(r"Internet\s+(\d+\.\d+\.\d+\.\d+)\s+\S+\s+([0-9a-fA-F]{4}\.[0-9a-fA-F]{4}\.[0-9a-fA-F]{4})", line)
        if m:
            arp[m.group(2).lower()] = m.group(1)
    return arp


def _valid_ip(value: str) -> bool:
    try:
        ipaddress.ip_address(value)
        return True
    except Exception:
        return False


def parse_lldp_neighbors(output: str) -> Dict[str, NeighborInfo]:
    neighbors: Dict[str, NeighborInfo] = {}
    blocks = re.split(r"\n\s*-{5,}\s*\n", output or "")
    for block in blocks:
        dev = ""; local = ""; remote = ""; mgmt = ""
        m = re.search(r"System Name:\s*(.+)", block)
        if m: dev = m.group(1).strip()
        m = re.search(r"Device ID:\s*(.+)", block)
        if m and not dev: dev = m.group(1).strip()
        m = re.search(r"Local Intf:\s*(\S+)", block)
        if m: local = normalize_intf(m.group(1))
        m = re.search(r"Local Interface:\s*(\S+)", block)
        if m: local = normalize_intf(m.group(1))
        m = re.search(r"Port id:\s*(.+)", block, re.I)
        if m: remote = normalize_intf(m.group(1).strip())
        m = re.search(r"Port Description:\s*(.+)", block)
        if m and not remote: remote = normalize_intf(m.group(1).strip())
        ips = re.findall(r"(?:Management Address|IP):\s*(\d+\.\d+\.\d+\.\d+)", block, flags=re.I)
        for ip in ips:
            if _valid_ip(ip):
                mgmt = ip; break
        if dev and local:
            neighbors[local] = NeighborInfo(local, dev, remote, mgmt, "LLDP")
    return neighbors


def parse_cdp_neighbors(output: str) -> Dict[str, NeighborInfo]:
    neighbors: Dict[str, NeighborInfo] = {}
    blocks = re.split(r"\n\s*-{5,}\s*\n", output or "")
    for block in blocks:
        dev = ""; local = ""; remote = ""; mgmt = ""; platform = ""
        m = re.search(r"Device ID:\s*(.+)", block)
        if m: dev = m.group(1).strip()
        m = re.search(r"Interface:\s*(\S+),\s*Port ID \(outgoing port\):\s*(.+)", block)
        if m:
            local = normalize_intf(m.group(1)); remote = normalize_intf(m.group(2).strip())
        m = re.search(r"IP address:\s*(\d+\.\d+\.\d+\.\d+)", block)
        if m and _valid_ip(m.group(1)): mgmt = m.group(1)
        m = re.search(r"Platform:\s*([^,]+)", block)
        if m: platform = m.group(1).strip()
        if dev and local:
            neighbors[local] = NeighborInfo(local, dev, remote, mgmt, "CDP", platform)
    return neighbors


def classify(f: InterfaceFinding, max_bps: int, threshold_mbps: int) -> InterfaceFinding:
    peak = max(f.input_bps, f.output_bps)
    threshold_bps = threshold_mbps * 1_000_000
    reasons = []
    if peak >= threshold_bps:
        f.severity = "high"; reasons.append(f"traffic exceeds {threshold_mbps} Mbps threshold")
    elif max_bps and peak >= max_bps * 0.60 and peak > 0:
        f.severity = "watch"; reasons.append("one of the top talker interfaces")
    downstreamish = f.mac_count >= 20 or f.interface.lower().startswith("po") or bool(f.neighbor)
    if downstreamish:
        f.role_guess = "uplink / downstream switch / aggregation"
    elif f.mac_count > 1:
        f.role_guess = "multi-MAC edge or small downstream device"
    else:
        f.role_guess = "likely endpoint"
    if f.neighbor:
        target = f"{f.neighbor} ({f.neighbor_ip})" if f.neighbor_ip else f.neighbor
        reasons.append(f"neighbor seen: {target}")
    if f.mac_count:
        reasons.append(f"{f.mac_count} MAC address(es) learned")
    f.reason = "; ".join(reasons) if reasons else "traffic currently below threshold"
    return f


def analyze(outputs: Dict[str, str], threshold_mbps: int) -> Tuple[List[InterfaceFinding], List[str], Dict[str, NeighborInfo]]:
    iface_rates = parse_show_interfaces(outputs.get("show interfaces", ""))
    statuses = parse_status(outputs.get("show interfaces status", ""))
    macs_by_port = parse_mac_table(outputs.get("show mac address-table", ""))
    arp = parse_arp(outputs.get("show arp", ""))
    neighbors = parse_cdp_neighbors(outputs.get("show cdp neighbors detail", ""))
    neighbors.update(parse_lldp_neighbors(outputs.get("show lldp neighbors detail", "")))
    findings: List[InterfaceFinding] = []
    max_bps = 0
    ports = set(iface_rates) | set(statuses) | set(macs_by_port) | set(neighbors)
    for port in ports:
        r = iface_rates.get(port, {}); s = statuses.get(port, {}); macs = sorted(set(macs_by_port.get(port, [])))
        ips = [arp[m] for m in macs if m in arp][:10]
        n = neighbors.get(port)
        f = InterfaceFinding(
            interface=port,
            input_bps=r.get("input_bps", 0), output_bps=r.get("output_bps", 0),
            input_pps=r.get("input_pps", 0), output_pps=r.get("output_pps", 0),
            status=s.get("status", ""), vlan=s.get("vlan", ""), duplex=s.get("duplex", ""), speed=s.get("speed", ""), type=s.get("type", ""),
            mac_count=len(macs), sample_macs=", ".join(macs[:10]), sample_ips=", ".join(ips),
            neighbor=n.device_id if n else "", neighbor_ip=n.management_ip if n else "", neighbor_remote_port=n.remote_interface if n else "",
        )
        max_bps = max(max_bps, f.input_bps, f.output_bps)
        findings.append(f)
    findings = [classify(f, max_bps, threshold_mbps) for f in findings]
    findings.sort(key=lambda x: max(x.input_bps, x.output_bps), reverse=True)
    summary = []
    high = [f for f in findings if f.severity == "high"]
    if high:
        top = high[0]
        direction = "ingress" if top.input_bps >= top.output_bps else "egress"
        summary.append(f"Top local suspect: {top.interface} with {direction} traffic at {human_bps(max(top.input_bps, top.output_bps))}.")
        if top.neighbor_ip:
            summary.append(f"Hot port has neighbor {top.neighbor} at {top.neighbor_ip}; recursive trace will follow that device when enabled.")
        elif top.sample_ips:
            summary.append(f"Likely local endpoint IP(s): {top.sample_ips}.")
        elif top.sample_macs:
            summary.append(f"Likely local endpoint MAC(s): {top.sample_macs}.")
    else:
        summary.append("No interfaces exceeded the configured threshold during this snapshot.")
    return findings[:75], summary, neighbors


def run_switch(ip: str, username: str, password: str, secret: str, port: int, timeout: int) -> Dict[str, str]:
    if ConnectHandler is None:
        raise RuntimeError("netmiko is not installed. Run start.bat or pip install -r requirements.txt.")
    device = {"device_type": "cisco_ios", "host": ip, "username": username, "password": password, "secret": secret or password, "port": port, "timeout": timeout, "banner_timeout": timeout, "auth_timeout": timeout, "fast_cli": False}
    outputs = {}
    with ConnectHandler(**device) as conn:
        try:
            conn.enable()
        except Exception:
            pass
        for cmd in COMMANDS:
            base_cmd = cmd.split(" | ")[0]
            if cmd == "terminal length 0":
                conn.send_command(cmd, expect_string=r"[#>]", read_timeout=timeout)
                continue
            try:
                outputs[base_cmd] = conn.send_command(cmd, expect_string=r"[#>]", read_timeout=timeout)
                time.sleep(0.15)
            except Exception as exc:
                outputs[base_cmd] = f"ERROR: {exc}"
    return outputs


def recursive_trace(seed_ip: str, username: str, password: str, secret: str, port: int, timeout: int, threshold_mbps: int, max_depth: int, max_devices: int, follow_watch: bool) -> Dict:
    scans: List[SwitchScan] = []
    edges: List[Dict[str, str]] = []
    visited: Set[str] = set()
    queue: List[Tuple[str, int, str, str, str]] = [(seed_ip, 0, "", "", "")]
    while queue and len(visited) < max_devices:
        ip, depth, parent_ip, parent_intf, parent_neighbor = queue.pop(0)
        if ip in visited:
            continue
        visited.add(ip)
        scan = SwitchScan(target_ip=ip, depth=depth, parent_ip=parent_ip, parent_interface=parent_intf, parent_neighbor=parent_neighbor, findings=[], summary=[], raw={})
        try:
            raw = run_switch(ip, username, password, secret, port, timeout)
            findings, summary, _neighbors = analyze(raw, threshold_mbps)
            scan.hostname = parse_hostname(raw, ip)
            scan.raw = raw; scan.findings = findings; scan.summary = summary
            if depth < max_depth:
                for f in findings:
                    peak = max(f.input_bps, f.output_bps)
                    should_follow = f.neighbor_ip and f.neighbor_ip not in visited and f.neighbor_ip != ip and (f.severity == "high" or (follow_watch and f.severity == "watch"))
                    if should_follow:
                        f.traced = True
                        edges.append({"from": ip, "to": f.neighbor_ip, "from_port": f.interface, "to_port": f.neighbor_remote_port, "neighbor": f.neighbor, "traffic": human_bps(peak), "severity": f.severity})
                        if all(q[0] != f.neighbor_ip for q in queue):
                            queue.append((f.neighbor_ip, depth + 1, ip, f.interface, f.neighbor))
        except Exception as exc:
            scan.error = str(exc)
        scans.append(scan)
    endpoint_candidates = []
    for scan in scans:
        if scan.error:
            continue
        for f in scan.findings or []:
            if f.severity in ("high", "watch") and not f.neighbor_ip:
                endpoint_candidates.append({"switch": scan.hostname or scan.target_ip, "switch_ip": scan.target_ip, "port": f.interface, "traffic": human_bps(max(f.input_bps, f.output_bps)), "ips": f.sample_ips, "macs": f.sample_macs, "reason": f.reason})
    return {"scans": scans, "edges": edges, "endpoint_candidates": endpoint_candidates, "visited_count": len(visited), "stopped_reason": "Max devices reached" if queue else "Trace complete"}


@app.get("/", response_class=HTMLResponse)
def index(request: Request):
    return templates.TemplateResponse("index.html", {"request": request, "title": APP_TITLE, "favicon": FAVICON_URL, "result": None})


@app.post("/scan", response_class=HTMLResponse)
def scan(request: Request, ip: str = Form(...), username: str = Form(...), password: str = Form(...), secret: str = Form(""), port: int = Form(22), timeout: int = Form(30), threshold_mbps: int = Form(100), recursive: str = Form("off"), max_depth: int = Form(3), max_devices: int = Form(25), follow_watch: str = Form("off")):
    result = {"target": ip, "threshold_mbps": threshold_mbps, "error": None, "human_bps": human_bps, "recursive": recursive == "on"}
    try:
        if recursive == "on":
            trace = recursive_trace(ip.strip(), username.strip(), password, secret, port, timeout, threshold_mbps, max_depth, max_devices, follow_watch == "on")
            result.update({"trace": {"scans": [asdict(s) for s in trace["scans"]], "edges": trace["edges"], "endpoint_candidates": trace["endpoint_candidates"], "visited_count": trace["visited_count"], "stopped_reason": trace["stopped_reason"]}})
        else:
            raw = run_switch(ip.strip(), username.strip(), password, secret, port, timeout)
            findings, summary, _ = analyze(raw, threshold_mbps)
            result.update({"summary": summary, "findings": [asdict(f) for f in findings], "raw": raw})
    except Exception as exc:
        result["error"] = str(exc)
    return templates.TemplateResponse("index.html", {"request": request, "title": APP_TITLE, "favicon": FAVICON_URL, "result": result})
