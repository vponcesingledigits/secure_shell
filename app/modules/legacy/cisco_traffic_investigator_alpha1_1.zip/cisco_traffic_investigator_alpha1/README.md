# Cisco Traffic Investigator Alpha 1.1

FastAPI web app for tracing excessive traffic through Cisco switches.

## What it does

1. Logs into a seed Cisco switch using SSH.
2. Runs interface, MAC, ARP, CDP, and LLDP show commands.
3. Ranks high-traffic interfaces.
4. Uses CDP/LLDP management IPs on hot ports to recursively log into neighbor switches using the same credentials.
5. Continues until it reaches likely endpoint ports, the max depth, the max device count, or devices it has already scanned.

## Start

Double-click `start.bat`, then browse to:

`http://127.0.0.1:8013`

## Notes

- Passwords and enable secrets are used only for the scan request and are not saved.
- Recursive tracing requires CDP or LLDP detail output to include a reachable management IP for the neighbor.
- The first pass is Cisco IOS focused. It can often read Cisco-like neighbors, but multi-vendor parsing should be added deliberately per platform.
- High traffic is based on the current `show interfaces` rate snapshot, not historical flow data.

## Recommended workflow

Start with a threshold like 100 Mbps. If the site is very busy, raise the threshold. If trying to chase smaller loops or bursts, lower the threshold and enable “Also follow watch-level ports.”
